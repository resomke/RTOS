/**
  ******************************************************************************
  * @file    app_config.h
  * @brief   任务一的所有可修改参数都集中在这里。
  *
  * 硬件：STM32F103C8T6 最小系统板 + 0.96" I2C OLED(SSD1306) + AHT20
  * 接线：OLED/AHT20 的 SCL -> PB6, SDA -> PB7, VCC -> 3.3V, GND -> GND
  ******************************************************************************
  */
#ifndef APP_CONFIG_H
#define APP_CONFIG_H

/* ========================== 1. 个人信息 ========================== */
/* 改成你自己的学号和姓名；姓名支持中文，但修改中文后需要重新生成字库：
 *   python tools/gen_font.py
 * 或者把学号/姓名发给代做者重新生成 HEX。 */
#define STUDENT_ID              "632407030413"
#define STUDENT_NAME            "李泓"
#define SCHOOL_NAME             "重庆交通大学"
#define LAB_NAME                "物联网205实训室"

/* 任务一第 3 项：长字符串滚动内容。
 * 中英文、数字、标点可以混合。 */
#define MARQUEE_TEXT            "天不生我EDG，VCTCN万古如长夜"

/* 任务一附加：SSD1306 硬件水平滚动页的两行内容。
 * 每行不要超过 128 像素（16x16 汉字最多 8 个）。 */
#define HW_SCROLL_LINE1         "重庆交通大学"
#define HW_SCROLL_LINE2         "物联网205实训室"

/* ========================== 2. 页面时间 ========================== */
#define PAGE_INFO_MS            4000U
#define PAGE_SENSOR_MS          6000U
#define PAGE_SOFT_SCROLL_MS     12000U
#define PAGE_HW_SCROLL_MS       8000U

/* 软件跑马灯：每 45 ms 左移 2 像素 */
#define APP_MARQUEE_STEP_PX     2U
#define APP_MARQUEE_PERIOD_MS   45U

/* AHT20 采样周期 */
#define AHT20_PERIOD_MS         2000U

/* ========================== 3. I2C 地址 ========================== */
/* 7 位地址。OLED 常见 0x3C，少数模块是 0x3D，代码会自动探测。 */
#define OLED_I2C_ADDR           0x3CU
#define OLED_I2C_ADDR_ALT       0x3DU
#define AHT20_I2C_ADDR          0x38U

/* ========================== 4. 功能开关 ========================== */
/* 1: 增加第 4 页，演示 SSD1306 硬件水平滚动（0x26/0x27/0x2F）
 * 0: 只保留前 3 页 */
#define APP_USE_HW_SCROLL_PAGE  1

/* 1: 使用 PA0 按键（按下接 GND）手动切页；0: 只用自动轮播 */
#define APP_USE_KEY_PA0         1

/* 1: 从 USART1(PA9/PA10, 115200) 输出启动信息和传感器数据 */
#define APP_USE_UART_LOG        1

#endif /* APP_CONFIG_H */
