/**
  ******************************************************************************
  * @file    board.h
  * @brief   最小系统板板载资源定义。
  ******************************************************************************
  */
#ifndef BOARD_H
#define BOARD_H

#include "stm32f1xx_hal.h"

/* Blue Pill / 最小系统板：LED 接 PC13，低电平点亮 */
#define LED_PORT                GPIOC
#define LED_PIN                 GPIO_PIN_13

/* 可选按键：PA0 接 GND，内部上拉。按下为低电平。 */
#define KEY_PORT                GPIOA
#define KEY_PIN                 GPIO_PIN_0

#define LED_ON()                HAL_GPIO_WritePin(LED_PORT, LED_PIN, GPIO_PIN_RESET)
#define LED_OFF()               HAL_GPIO_WritePin(LED_PORT, LED_PIN, GPIO_PIN_SET)
#define LED_TOGGLE()            HAL_GPIO_TogglePin(LED_PORT, LED_PIN)

#endif /* BOARD_H */
