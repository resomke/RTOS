/**
  ******************************************************************************
  * @file    syscalls.c
  * @brief   newlib 最小系统调用桩，避免链接 nosys 库时出现一堆警告。
  *
  * 本工程本身不使用 printf/malloc；保留这些桩是为了让用户后续加
  * printf 调试时也能直接链接。_write 已重定向到 USART1。
  ******************************************************************************
  */
#include "bsp_uart.h"
#include <errno.h>
#include <stddef.h>
#include <stdint.h>
#include <sys/stat.h>

extern char _end;
extern char _estack;

void *_sbrk(ptrdiff_t incr)
{
    static char *heap_end;
    char *previous;

    if (heap_end == NULL)
    {
        heap_end = &_end;
    }

    previous = heap_end;

    if ((heap_end + incr) > (&_estack))
    {
        errno = ENOMEM;
        return (void *)-1;
    }

    heap_end += incr;
    return previous;
}

int _close(int fd)
{
    (void)fd;
    return -1;
}

int _fstat(int fd, struct stat *st)
{
    (void)fd;
    st->st_mode = S_IFCHR;
    return 0;
}

int _isatty(int fd)
{
    (void)fd;
    return 1;
}

int _lseek(int fd, int ptr, int dir)
{
    (void)fd;
    (void)ptr;
    (void)dir;
    return 0;
}

int _read(int fd, char *ptr, int len)
{
    (void)fd;
    (void)ptr;
    (void)len;
    return 0;
}

int _write(int fd, char *ptr, int len)
{
    (void)fd;
    for (int i = 0; i < len; ++i)
    {
        bsp_uart_putc(ptr[i]);
    }
    return len;
}

int _kill(int pid, int sig)
{
    (void)pid;
    (void)sig;
    errno = EINVAL;
    return -1;
}

int _getpid(void)
{
    return 1;
}

void _exit(int status)
{
    (void)status;
    while (1)
    {
    }
}
