/**
  ******************************************************************************
  * @file    main.c
  * @brief   任务二（2）：STM32F103C8T6 裸机 AHT20 温湿度采集
  *
  * 功能：每隔 2 s 读取一次 AHT20，通过 USART1(PA9/PA10, 115200-8-N-1) 输出。
  * 接线：AHT20 VCC=3.3V、GND=GND、SCL=PB6、SDA=PB7。
  *
  * 本工程不使用 uC/OS，适合先验证传感器和 I2C 硬件；
  * 任务二（3）的 RTOS 版本见 RTOS_AHT20 工程。
  ******************************************************************************
  */
#include "main.h"
#include "board.h"
#include "aht20.h"
#include "bsp_i2c.h"
#include "bsp_uart.h"

static void MX_GPIO_Init(void);

static void uart_put_1dec(float value)
{
    int32_t x;

    if (value >= 0.0f)
    {
        x = (int32_t)(value * 10.0f + 0.5f);
    }
    else
    {
        x = (int32_t)(value * 10.0f - 0.5f);
    }

    if (x < 0)
    {
        bsp_uart_putc('-');
        x = -x;
    }

    bsp_uart_put_u32((uint32_t)(x / 10));
    bsp_uart_putc('.');
    bsp_uart_putc((char)('0' + (x % 10)));
}

int main(void)
{
    aht20_data_t data;
    uint32_t next;
    bool init_ok;

    HAL_Init();
    SystemClock_Config();
    MX_GPIO_Init();

    bsp_uart_init();
    bsp_i2c_init();

    bsp_uart_puts("\r\n============================================\r\n");
    bsp_uart_puts("  Task2: AHT20 bare-metal, every 2 s\r\n");
    bsp_uart_puts("  I2C1: PB6=SCL, PB7=SDA, 100 kHz, addr=0x38\r\n");
    bsp_uart_puts("  USART1: PA9=TX, PA10=RX, 115200-8-N-1\r\n");
    bsp_uart_puts("============================================\r\n");

    init_ok = aht20_init();
    if (init_ok)
    {
        bsp_uart_puts("[AHT20] init OK\r\n");
    }
    else
    {
        bsp_uart_puts("[AHT20] init FAILED, check 3.3V/GND/PB6/PB7\r\n");
    }

    next = HAL_GetTick();

    while (1)
    {
        if ((int32_t)(HAL_GetTick() - next) >= 0)
        {
            next += 2000U;
            LED_TOGGLE();

            if (aht20_read(&data))
            {
                bsp_uart_puts("[AHT20] T=");
                uart_put_1dec(data.temperature);
                bsp_uart_puts(" C, RH=");
                uart_put_1dec(data.humidity);
                bsp_uart_puts(" %, CRC=");
                bsp_uart_puts(data.crc_ok ? "OK" : "ERR");
                bsp_uart_puts("\r\n");
            }
            else
            {
                bsp_uart_puts("[AHT20] read failed, status=0x");
                bsp_uart_put_hex8(aht20_last_status());
                bsp_uart_puts("\r\n");
            }
        }
    }
}

/**
  * @brief 系统时钟：优先 72 MHz(HSE)，失败则 64 MHz(HSI)。
  */
void SystemClock_Config(void)
{
    RCC_OscInitTypeDef osc = {0};
    RCC_ClkInitTypeDef clk = {0};

    osc.OscillatorType = RCC_OSCILLATORTYPE_HSE;
    osc.HSEState = RCC_HSE_ON;
    osc.HSEPredivValue = RCC_HSE_PREDIV_DIV1;
    osc.PLL.PLLState = RCC_PLL_ON;
    osc.PLL.PLLSource = RCC_PLLSOURCE_HSE;
    osc.PLL.PLLMUL = RCC_PLL_MUL9;

    if (HAL_RCC_OscConfig(&osc) != HAL_OK)
    {
        HAL_RCC_DeInit();

        osc.OscillatorType = RCC_OSCILLATORTYPE_HSI;
        osc.HSIState = RCC_HSI_ON;
        osc.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
        osc.PLL.PLLState = RCC_PLL_ON;
        osc.PLL.PLLSource = RCC_PLLSOURCE_HSI_DIV2;
        osc.PLL.PLLMUL = RCC_PLL_MUL16;

        if (HAL_RCC_OscConfig(&osc) != HAL_OK)
        {
            Error_Handler();
        }
    }

    clk.ClockType = RCC_CLOCKTYPE_HCLK | RCC_CLOCKTYPE_SYSCLK |
                    RCC_CLOCKTYPE_PCLK1 | RCC_CLOCKTYPE_PCLK2;
    clk.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
    clk.AHBCLKDivider = RCC_SYSCLK_DIV1;
    clk.APB1CLKDivider = RCC_HCLK_DIV2;
    clk.APB2CLKDivider = RCC_HCLK_DIV1;

    if (HAL_RCC_ClockConfig(&clk, FLASH_LATENCY_2) != HAL_OK)
    {
        Error_Handler();
    }
}

static void MX_GPIO_Init(void)
{
    GPIO_InitTypeDef gpio = {0};

    __HAL_RCC_GPIOA_CLK_ENABLE();
    __HAL_RCC_GPIOB_CLK_ENABLE();
    __HAL_RCC_GPIOC_CLK_ENABLE();

    HAL_GPIO_WritePin(LED_PORT, LED_PIN, GPIO_PIN_SET);
    gpio.Pin = LED_PIN;
    gpio.Mode = GPIO_MODE_OUTPUT_PP;
    gpio.Speed = GPIO_SPEED_FREQ_LOW;
    HAL_GPIO_Init(LED_PORT, &gpio);
}

void Error_Handler(void)
{
    __disable_irq();
    while (1)
    {
        LED_TOGGLE();
        for (volatile uint32_t i = 0; i < 250000U; ++i)
        {
            __NOP();
        }
    }
}
