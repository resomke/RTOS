# 任务二（2）：裸机 AHT20 温湿度采集

这是任务二的**裸机版本**：不使用 uC/OS，只用 HAL + 超级循环，每 2 s 读一次 AHT20 并通过 USART1 输出。

## 功能

- I2C1：PB6=SCL，PB7=SDA，100 kHz。
- AHT20：7 位地址 0x38，写 0x70、读 0x71。
- 初始化：等待 40 ms，读状态；若 bit3=0，发送 `0xBE 0x08 0x00`，等待 10 ms。
- 测量：每 2 s 发送 `0xAC 0x33 0x00`，等待 80 ms，读 7 字节，CRC8 校验并换算。
- 串口：USART1 PA9=TX、PA10=RX，115200-8-N-1，UTF-8。

## 打开与编译

1. 打开 `MDK-ARM/Task2_AHT20_Bare.uvprojx`。
2. 编译器：**ARM Compiler 6（AC6）**，工程已按 AC6 配置。
3. F7 编译，F8 下载。

## 烧录

`flash/Task2_AHT20_Bare.hex` 是编译好的固件，可直接烧录：

```powershell
STM32_Programmer_CLI.exe -c port=SWD -w flash\Task2_AHT20_Bare.hex -v -rst
```

## 接线

| STM32F103C8T6 | AHT20 / USB-TTL |
|---|---|
| 3.3 V | AHT20 VCC |
| GND | AHT20 GND、USB-TTL GND |
| PB6 | AHT20 SCL |
| PB7 | AHT20 SDA |
| PA9 | USB-TTL RX |
| PA10 | USB-TTL TX（可不接） |

## 预期串口输出

```text
============================================
  Task2: AHT20 bare-metal, every 2 s
  I2C1: PB6=SCL, PB7=SDA, 100 kHz, addr=0x38
  USART1: PA9=TX, PA10=RX, 115200-8-N-1
============================================
[AHT20] init OK
[AHT20] T=25.0 C, RH=50.0 %, CRC=OK
[AHT20] T=25.1 C, RH=50.2 %, CRC=OK
```

## 说明

- 本工程只覆盖任务二（2）；任务二（3）的 RTOS 版本见 `RTOS_AHT20` 工程。
- AHT20 模块 SCL/SDA 一般自带 4.7 kΩ 上拉；若没有，需外接。
- 如果串口中文乱码，把串口助手编码改为 UTF-8。
