﻿# -*- coding: utf-8 -*-
"""Build the Chinese lab report DOCX for the uC/OS-III + AHT20 experiment."""
import json
import os
import re
import sys

from docx import Document
from docx.enum.section import WD_SECTION
from docx.enum.table import WD_ALIGN_VERTICAL, WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_BREAK, WD_LINE_SPACING, WD_TAB_ALIGNMENT, WD_TAB_LEADER
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Cm, Pt, RGBColor

BASE = os.path.dirname(os.path.abspath(__file__))
ASSETS = os.path.join(BASE, "report_assets")
OUT_DOCX = os.path.join(BASE, "嵌入式RTOS与I2C实验报告.docx")
TOC_PAGES_JSON = os.path.join(BASE, "toc_pages.json")

NAVY = RGBColor(0x1F, 0x38, 0x64)
BLUE = RGBColor(0x2F, 0x55, 0x97)
DARK = RGBColor(0x26, 0x26, 0x26)
GRAY = RGBColor(0x59, 0x59, 0x59)
LIGHT_GRAY = RGBColor(0x7F, 0x7F, 0x7F)
RED = RGBColor(0xC0, 0x00, 0x00)

TOC_ENTRIES = [
    (1, "1", "实验任务与方案"),
    (1, "2", "系统总体设计"),
    (2, "2.1", "硬件资源与接线"),
    (2, "2.2", "软件分层"),
    (2, "2.3", "任务划分"),
    (2, "2.4", "调度时序"),
    (1, "3", "任务一：uC/OS-III 移植"),
    (2, "3.1", "RTOS 基本概念"),
    (2, "3.2", "uC/OS-III 源码结构"),
    (2, "3.3", "Cortex-M3 移植原理"),
    (2, "3.4", "移植步骤"),
    (2, "3.5", "移植中的问题与解决"),
    (1, "4", "任务二：I2C 总线与 AHT20"),
    (2, "4.1", "I2C 总线协议"),
    (2, "4.2", "软件 I2C 与硬件 I2C"),
    (2, "4.3", "STM32F1 硬件 I2C 配置"),
    (2, "4.4", "AHT20 数据手册要点"),
    (2, "4.5", "AHT20 驱动实现"),
    (2, "4.6", "任务三集成"),
    (2, "4.7", "串口输出"),
    (2, "4.8", "示波器 / 逻辑分析仪观察"),
    (2, "4.9", "I2C 调试中的问题与解决"),
    (1, "5", "实验结果与分析"),
    (2, "5.1", "编译结果"),
    (2, "5.2", "LED 与任务周期"),
    (2, "5.3", "串口与温湿度"),
    (2, "5.4", "实时性分析"),
    (1, "6", "结论"),
    (1, "", "参考文献"),
    (1, "A", "工程结构与编译信息"),
    (1, "B", "关键源码"),
    (1, "C", "实测记录表"),
]


def load_pages():
    if os.path.exists(TOC_PAGES_JSON):
        with open(TOC_PAGES_JSON, "r", encoding="utf-8") as f:
            return json.load(f)
    return {}


def set_cell_shading(cell, fill):
    tcPr = cell._tc.get_or_add_tcPr()
    shd = OxmlElement("w:shd")
    shd.set(qn("w:val"), "clear")
    shd.set(qn("w:color"), "auto")
    shd.set(qn("w:fill"), fill)
    tcPr.append(shd)


def set_cell_margins(cell, top=40, bottom=40, left=80, right=80):
    tcPr = cell._tc.get_or_add_tcPr()
    tcMar = OxmlElement("w:tcMar")
    for name, value in (("top", top), ("bottom", bottom), ("left", left), ("right", right)):
        el = OxmlElement(f"w:{name}")
        el.set(qn("w:w"), str(value))
        el.set(qn("w:type"), "dxa")
        tcMar.append(el)
    tcPr.append(tcMar)


def set_table_borders(table, color="BFBFBF", sz="4"):
    tbl = table._tbl
    tblPr = tbl.tblPr
    borders = OxmlElement("w:tblBorders")
    for edge in ("top", "left", "bottom", "right", "insideH", "insideV"):
        el = OxmlElement(f"w:{edge}")
        el.set(qn("w:val"), "single")
        el.set(qn("w:sz"), sz)
        el.set(qn("w:space"), "0")
        el.set(qn("w:color"), color)
        borders.append(el)
    tblPr.append(borders)


def set_table_no_borders(table):
    tbl = table._tbl
    tblPr = tbl.tblPr
    borders = OxmlElement("w:tblBorders")
    for edge in ("top", "left", "bottom", "right", "insideH", "insideV"):
        el = OxmlElement(f"w:{edge}")
        el.set(qn("w:val"), "nil")
        borders.append(el)
    tblPr.append(borders)


def set_repeat_header(row):
    trPr = row._tr.get_or_add_trPr()
    el = OxmlElement("w:tblHeader")
    el.set(qn("w:val"), "true")
    trPr.append(el)


def prevent_row_split(row):
    trPr = row._tr.get_or_add_trPr()
    el = OxmlElement("w:cantSplit")
    el.set(qn("w:val"), "true")
    trPr.append(el)


def set_run_font(run, name="宋体", size=10.5, bold=None, color=None, italic=None):
    run.font.name = name
    run._element.get_or_add_rPr().rFonts.set(qn("w:eastAsia"), name)
    run.font.size = Pt(size)
    if bold is not None:
        run.font.bold = bold
    if italic is not None:
        run.font.italic = italic
    if color is not None:
        run.font.color.rgb = color


def add_field(paragraph, instr):
    run = paragraph.add_run()
    fldChar = OxmlElement("w:fldChar")
    fldChar.set(qn("w:fldCharType"), "begin")
    instrText = OxmlElement("w:instrText")
    instrText.set(qn("xml:space"), "preserve")
    instrText.text = instr
    fldChar2 = OxmlElement("w:fldChar")
    fldChar2.set(qn("w:fldCharType"), "separate")
    t = OxmlElement("w:t")
    t.text = "1"
    fldChar3 = OxmlElement("w:fldChar")
    fldChar3.set(qn("w:fldCharType"), "end")
    run._r.append(fldChar)
    run._r.append(instrText)
    run._r.append(fldChar2)
    run._r.append(t)
    run._r.append(fldChar3)


def add_runs(paragraph, text, size=10.5, color=DARK, base_bold=False):
    parts = re.split(r"(\*\*.*?\*\*|`.*?`)", text)
    for part in parts:
        if not part:
            continue
        if part.startswith("**") and part.endswith("**") and len(part) > 4:
            run = paragraph.add_run(part[2:-2])
            set_run_font(run, "宋体", size, True, color)
        elif part.startswith("`") and part.endswith("`") and len(part) > 2:
            run = paragraph.add_run(part[1:-1])
            set_run_font(run, "Consolas", max(8.5, size - 1.0), base_bold, RGBColor(0x1F, 0x4E, 0x79))
            run._element.get_or_add_rPr().rFonts.set(qn("w:eastAsia"), "宋体")
        else:
            run = paragraph.add_run(part)
            set_run_font(run, "宋体", size, base_bold, color)


def body(text, indent=True, size=10.5, space_after=3, align=WD_ALIGN_PARAGRAPH.JUSTIFY):
    p = doc.add_paragraph()
    pf = p.paragraph_format
    pf.line_spacing = 1.35
    pf.space_before = Pt(0)
    pf.space_after = Pt(space_after)
    pf.alignment = align
    if indent:
        pf.first_line_indent = Pt(size * 2)
    add_runs(p, text, size)
    return p


def bullet(text, level=0):
    p = doc.add_paragraph(style="List Bullet")
    p.paragraph_format.left_indent = Cm(0.75 + 0.6 * level)
    p.paragraph_format.first_line_indent = Cm(-0.35)
    p.paragraph_format.line_spacing = 1.3
    p.paragraph_format.space_after = Pt(2)
    add_runs(p, text, 10.5)
    return p


def numbered(text):
    p = doc.add_paragraph(style="List Number")
    p.paragraph_format.left_indent = Cm(0.9)
    p.paragraph_format.first_line_indent = Cm(-0.45)
    p.paragraph_format.line_spacing = 1.3
    p.paragraph_format.space_after = Pt(2)
    add_runs(p, text, 10.5)
    return p


def h1(text, page_break=True):
    p = doc.add_paragraph(style="Heading 1")
    p.paragraph_format.page_break_before = bool(page_break)
    p.paragraph_format.keep_with_next = True
    r = p.add_run(text)
    set_run_font(r, "黑体", 16, True, NAVY)
    p.paragraph_format.space_before = Pt(12)
    p.paragraph_format.space_after = Pt(8)
    return p


def h2(text):
    p = doc.add_paragraph(style="Heading 2")
    p.paragraph_format.keep_with_next = True
    r = p.add_run(text)
    set_run_font(r, "黑体", 13, True, BLUE)
    p.paragraph_format.space_before = Pt(10)
    p.paragraph_format.space_after = Pt(4)
    return p


def h3(text):
    p = doc.add_paragraph(style="Heading 3")
    p.paragraph_format.keep_with_next = True
    r = p.add_run(text)
    set_run_font(r, "黑体", 11.5, True, DARK)
    p.paragraph_format.space_before = Pt(6)
    p.paragraph_format.space_after = Pt(3)
    return p


def caption(text):
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.space_before = Pt(2)
    p.paragraph_format.space_after = Pt(6)
    add_runs(p, text, 9, GRAY)
    for r in p.runs:
        r.font.italic = False
    return p


def note(text):
    p = doc.add_paragraph()
    p.paragraph_format.left_indent = Cm(0.5)
    p.paragraph_format.right_indent = Cm(0.5)
    p.paragraph_format.space_before = Pt(3)
    p.paragraph_format.space_after = Pt(6)
    p.paragraph_format.line_spacing = 1.2
    add_runs(p, text, 9, GRAY)
    for r in p.runs:
        r.font.italic = True
    return p


def figure(filename, width_cm, cap):
    path = os.path.join(ASSETS, filename)
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.space_before = Pt(3)
    p.paragraph_format.space_after = Pt(0)
    p.add_run().add_picture(path, width=Cm(width_cm))
    caption(cap)


def table(headers, rows, widths=None, cap=None, size=9, header_fill="D9E2F3", align_center=True, keep=False):
    t = doc.add_table(rows=1, cols=len(headers))
    t.style = "Table Grid"
    t.alignment = WD_TABLE_ALIGNMENT.CENTER
    t.autofit = False
    set_table_borders(t)
    hdr = t.rows[0]
    set_repeat_header(hdr)
    prevent_row_split(hdr)
    for i, text in enumerate(headers):
        cell = hdr.cells[i]
        set_cell_shading(cell, header_fill)
        set_cell_margins(cell)
        cell.vertical_alignment = WD_ALIGN_VERTICAL.CENTER
        p = cell.paragraphs[0]
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        p.paragraph_format.space_after = Pt(0)
        p.paragraph_format.line_spacing = 1.05
        add_runs(p, text, size, DARK, base_bold=True)
        if widths:
            cell.width = Cm(widths[i])
    for row_data in rows:
        row = t.add_row()
        prevent_row_split(row)
        for i, text in enumerate(row_data):
            cell = row.cells[i]
            set_cell_margins(cell)
            cell.vertical_alignment = WD_ALIGN_VERTICAL.CENTER
            p = cell.paragraphs[0]
            p.alignment = WD_ALIGN_PARAGRAPH.CENTER if (align_center and i > 0) else WD_ALIGN_PARAGRAPH.LEFT
            p.paragraph_format.space_after = Pt(0)
            p.paragraph_format.line_spacing = 1.1
            add_runs(p, str(text), size)
            if widths:
                cell.width = Cm(widths[i])
    if widths:
        for row in t.rows:
            for i, cell in enumerate(row.cells):
                cell.width = Cm(widths[i])
    if keep:
        for row in t.rows:
            for cell in row.cells:
                for p in cell.paragraphs:
                    p.paragraph_format.keep_with_next = True
    if cap:
        caption(cap)
    else:
        doc.add_paragraph().paragraph_format.space_after = Pt(0)
    return t


def code_block(code, cap=None, size=8.0):
    code = code.strip("\n")
    t = doc.add_table(rows=1, cols=1)
    t.alignment = WD_TABLE_ALIGNMENT.CENTER
    t.autofit = False
    prevent_row_split(t.rows[0])
    set_table_borders(t, color="D0D0D0", sz="4")
    cell = t.cell(0, 0)
    cell.width = Cm(15.4)
    set_cell_shading(cell, "F7F7F7")
    set_cell_margins(cell, top=60, bottom=60, left=110, right=110)
    p = cell.paragraphs[0]
    p.paragraph_format.space_after = Pt(0)
    p.paragraph_format.line_spacing = 1.0
    first = True
    for line in code.split("\n"):
        if first:
            para = p
            first = False
        else:
            para = cell.add_paragraph()
            para.paragraph_format.space_after = Pt(0)
            para.paragraph_format.line_spacing = 1.0
        run = para.add_run(line if line else " ")
        set_run_font(run, "Consolas", size, False, RGBColor(0x1A, 0x1A, 0x1A))
        run._element.get_or_add_rPr().rFonts.set(qn("w:eastAsia"), "宋体")
    if cap:
        caption(cap)
    else:
        doc.add_paragraph().paragraph_format.space_after = Pt(0)
    return t


def page_setup():
    sec = doc.sections[0]
    sec.page_width = Cm(21.0)
    sec.page_height = Cm(29.7)
    sec.top_margin = Cm(2.54)
    sec.bottom_margin = Cm(2.4)
    sec.left_margin = Cm(3.0)
    sec.right_margin = Cm(2.5)
    sec.header_distance = Cm(1.2)
    sec.footer_distance = Cm(1.2)
    sec.different_first_page_header_footer = True

    # Normal style
    st = doc.styles["Normal"]
    st.font.name = "宋体"
    st._element.rPr.rFonts.set(qn("w:eastAsia"), "宋体")
    st.font.size = Pt(10.5)

    for name, size, color in (("Heading 1", 16, NAVY), ("Heading 2", 13, BLUE), ("Heading 3", 11.5, DARK)):
        st = doc.styles[name]
        st.font.name = "黑体"
        st._element.rPr.rFonts.set(qn("w:eastAsia"), "黑体")
        st.font.size = Pt(size)
        st.font.bold = True
        st.font.color.rgb = color

    for name in ("List Bullet", "List Number"):
        st = doc.styles[name]
        st.font.name = "宋体"
        st._element.rPr.rFonts.set(qn("w:eastAsia"), "宋体")
        st.font.size = Pt(10.5)

    # Header (not first page)
    header = sec.header
    hp = header.paragraphs[0]
    hp.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    r = hp.add_run("嵌入式实时操作系统实验报告  |  STM32F103C8T6 + uC/OS-III + AHT20")
    set_run_font(r, "宋体", 8.5, False, LIGHT_GRAY)
    # bottom border on header
    pPr = hp._p.get_or_add_pPr()
    pbdr = OxmlElement("w:pBdr")
    bottom = OxmlElement("w:bottom")
    bottom.set(qn("w:val"), "single")
    bottom.set(qn("w:sz"), "4")
    bottom.set(qn("w:space"), "1")
    bottom.set(qn("w:color"), "BFBFBF")
    pbdr.append(bottom)
    pPr.append(pbdr)

    # Footer with PAGE / NUMPAGES
    footer = sec.footer
    fp = footer.paragraphs[0]
    fp.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r = fp.add_run("第 ")
    set_run_font(r, "宋体", 9, False, GRAY)
    add_field(fp, " PAGE ")
    r = fp.add_run(" 页 / 共 ")
    set_run_font(r, "宋体", 9, False, GRAY)
    add_field(fp, " NUMPAGES ")
    r = fp.add_run(" 页")
    set_run_font(r, "宋体", 9, False, GRAY)


def cover():
    # Top rule
    p = doc.add_paragraph()
    p.paragraph_format.space_before = Pt(10)
    p.paragraph_format.space_after = Pt(0)
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r = p.add_run("嵌入式实时操作系统")
    set_run_font(r, "黑体", 20, True, NAVY)

    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.space_before = Pt(4)
    p.paragraph_format.space_after = Pt(26)
    r = p.add_run("实 验 报 告")
    set_run_font(r, "黑体", 30, True, NAVY)

    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.space_before = Pt(8)
    p.paragraph_format.space_after = Pt(4)
    r = p.add_run("uC/OS-III 在 STM32F103C8T6 上的移植")
    set_run_font(r, "黑体", 18, True, DARK)

    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.space_before = Pt(0)
    p.paragraph_format.space_after = Pt(30)
    r = p.add_run("与 I2C AHT20 温湿度采集")
    set_run_font(r, "黑体", 18, True, DARK)

    # Decorative line
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.space_after = Pt(28)
    r = p.add_run("────────────────────────────")
    set_run_font(r, "宋体", 12, False, BLUE)

    info = [
        ("姓    名", "________________"),
        ("学    号", "________________"),
        ("班    级", "________________"),
        ("专    业", "________________"),
        ("指导教师", "________________"),
        ("日    期", "2026 年 10 月"),
    ]
    for k, v in info:
        p = doc.add_paragraph()
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        p.paragraph_format.space_after = Pt(9)
        r0 = p.add_run(k + "：")
        set_run_font(r0, "宋体", 12, False, DARK)
        r1 = p.add_run(v)
        set_run_font(r1, "宋体", 12, False, DARK)

    p = doc.add_paragraph()
    p.paragraph_format.space_before = Pt(40)
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r = p.add_run("代码工程：RTOS_AHT20（Keil MDK-ARM）")
    set_run_font(r, "宋体", 9.5, False, GRAY)
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r = p.add_run("开发环境：Keil MDK 5.24a + ARM Compiler 5.06 + STM32F1 HAL")
    set_run_font(r, "宋体", 9.5, False, GRAY)


def toc():
    doc.add_page_break()
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.space_before = Pt(0)
    p.paragraph_format.space_after = Pt(14)
    r = p.add_run("目  录")
    set_run_font(r, "黑体", 18, True, NAVY)

    pages = load_pages()
    for level, num, title in TOC_ENTRIES:
        p = doc.add_paragraph()
        p.paragraph_format.space_before = Pt(3 if level == 1 else 1)
        p.paragraph_format.space_after = Pt(3 if level == 1 else 1)
        p.paragraph_format.left_indent = Cm(0 if level == 1 else 0.8)
        p.paragraph_format.tab_stops.add_tab_stop(Cm(15.3), WD_TAB_ALIGNMENT.RIGHT, WD_TAB_LEADER.DOTS)
        label = ("附录 " + num + "  " + title) if num in ("A", "B", "C") else ((num + "  " if num else "") + title)
        r0 = p.add_run(label + "\t")
        set_run_font(r0, "宋体", 10.5 if level == 1 else 10, level == 1, DARK if level == 1 else GRAY)
        key = num if num else title
        r1 = p.add_run(str(pages.get(key, "—")))
        set_run_font(r1, "宋体", 9.5, False, GRAY)

    note("提示：目录页码与正文页脚一致；若在 Word 中增删内容导致页码变化，请按实际页码手动修改。")


def abstract():
    doc.add_page_break()
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.space_after = Pt(10)
    r = p.add_run("摘  要")
    set_run_font(r, "黑体", 16, True, NAVY)

    body(
        "本实验以 STM32F103C8T6 最小系统板为硬件平台，完成 uC/OS-III 实时操作系统的移植，"
        "并在此基础上构建三个周期任务：Task1 以 1 s 周期控制 PC13 板载 LED，Task2 以 3 s 周期控制 PB12 外接 LED，"
        "Task3 以 2 s 周期通过 I2C1 采集 AHT20 温湿度传感器，并经 USART1 将问候语和温湿度数据发送到上位机。"
        "移植工作包括 uC/OS-III 源码与 Cortex-M3 移植层文件的加入、os_cfg.h 等配置文件裁剪、"
        "启动文件中 PendSV 向量和 SysTick 中断的接管、OSInit/OSStart 启动流程以及任务栈和优先级的分配。"
    )
    body(
        "I2C 部分采用 STM32F1 硬件 I2C1，PB6/PB7 复用开漏，总线速率 100 kHz。AHT20 的 7 位地址为 0x38，"
        "写地址 0x70、读地址 0x71；上电后先读状态字节，若校准位 bit3 为 0，则发送 0xBE 0x08 0x00 完成初始化；"
        "每次测量发送 0xAC 0x33 0x00，等待约 80 ms 后读取 7 字节，按 20 位湿度、20 位温度格式换算，并用 CRC8 校验。"
        "程序在 Keil MDK 5.24a + ARMCC 5.06 下编译通过，代码约 14.1 KB、RAM 约 7.9 KB，三个任务按设计周期稳定运行。"
    )
    body(
        "报告给出了完整的移植步骤、任务调度分析、I2C 时序重绘与测量方法、AHT20 命令解析、串口输出格式以及常见问题处理，"
        "并附有可直接烧录的 HEX 文件和 Keil 工程。"
    )
    p = doc.add_paragraph()
    p.paragraph_format.space_before = Pt(10)
    add_runs(p, "**关键词：**uC/OS-III；STM32F103C8T6；移植；多任务；I2C；AHT20；温湿度", 10.5)

def section1():
    h1("1  实验任务与方案")

    h2("1.1  任务分解")
    body(
        "题目要求在以 STM32F103C8T6 为核心的最小系统板上移植 uC/OS，构建至少三个任务：两个 LED 任务分别以 1 s、3 s 周期点亮和熄灭 LED；"
        "第三个任务以 2 s 周期通过串口发送问候语，并在任务二完成后改为每 2 s 采集一次 AHT20 温湿度并上传。"
        "本工程把“问候语”和“温湿度”放在同一个 2 s 周期内输出，既保留任务一对第三个任务的要求，也完成任务二（3）的改造。"
    )
    table(
        ["任务", "周期", "优先级", "主要动作", "验收现象"],
        [
            ["Task1", "1 s", "4", "PC13 板载 LED 亮 0.5 s、灭 0.5 s", "LED1 以 1 Hz 均匀闪烁，占空比约 50%"],
            ["Task2", "3 s", "5", "PB12 外接 LED 亮 1.5 s、灭 1.5 s", "LED2 以 1/3 Hz 闪烁，与 LED1 有固定相位差"],
            ["Task3", "2 s", "6", "读 AHT20，USART1 输出问候语 + T/RH", "串口每 2 s 出现一组数据，CRC 正常"],
        ],
        widths=[2.0, 1.8, 1.6, 6.2, 4.0],
        cap="表 1-1  三个应用任务的设计指标",
    )
    note(
        "说明：任务二（2）的裸机版本与任务三共用 aht20.c、bsp_i2c.c 和 bsp_uart.c，只是主循环不同；"
        "本工程以任务三的 RTOS 形态实现，已覆盖“每 2 s 采集一次并通过串口输出”的要求。"
    )

    h2("1.2  实验目标")
    bullet("理解 RTOS 的任务、TCB、就绪表、调度器、系统节拍、上下文切换和临界区等基本概念。")
    bullet("掌握 uC/OS-III 在 Cortex-M3 上的移植文件组成，能独立完成源码加入、配置裁剪和启动文件修改。")
    bullet("掌握 STM32F1 硬件 I2C 的初始化、阻塞收发、总线恢复和地址扫描方法。")
    bullet("读懂 AHT20 数据手册中的地址、命令、状态位、数据格式和 CRC 校验，能编写稳定驱动。")
    bullet("能使用示波器或逻辑分析仪观察 I2C 的 START、地址、ACK、数据和 STOP，并能对照协议解释波形。")

    h2("1.3  开发环境")
    table(
        ["项目", "配置"],
        [
            ["MCU", "STM32F103C8T6，Cortex-M3，72 MHz，64 KB Flash，20 KB SRAM"],
            ["开发板", "Blue Pill / 最小系统板，板载 PC13 LED，8 MHz 晶振"],
            ["RTOS", "uC/OS-III V3.01.2，Cortex-M3 RealView 移植层"],
            ["HAL", "STM32F1xx HAL Driver，CMSIS Cortex-M3"],
            ["IDE / 编译器", "Keil MDK 5.24a，ARM Compiler 5.06（AC5）"],
            ["调试器", "ST-Link V2（SWD）"],
            ["串口工具", "USB-TTL（CH340），115200-8-N-1，UTF-8"],
            ["测量仪器", "100 MHz 双通道示波器，或 24 MHz 8 通道逻辑分析仪"],
        ],
        widths=[3.0, 12.4],
        keep=True,
        cap="表 1-2  软硬件开发环境",
    )

    h2("1.4  总体方案")
    body(
        "系统上电后先完成 HAL、时钟、GPIO、USART1 和 I2C1 的初始化，再调用 OSInit() 建立 uC/OS-III 的内部数据结构，"
        "创建起始任务并调用 OSStart() 交出 CPU 控制权。起始任务初始化 SysTick 节拍、CPU 和串口 Banner，"
        "然后创建三个应用任务并挂起自己。此后由 SysTick 产生 1 ms 节拍，PendSV 完成上下文切换，"
        "三个任务按照优先级和延时周期并发运行。"
    )
    body(
        "Task3 在第一次运行时完成 AHT20 的上电等待、状态读取和必要的校准命令；之后每 2 s 触发一次测量，"
        "读取 7 字节数据，做 CRC8 校验和浮点换算，再通过 USART1 发送。LED 任务只操作 GPIO，"
        "不占用 I2C 和串口，因此三个任务之间不需要额外的互斥信号量；如果后续增加 OLED 或第二个 I2C 设备，"
        "应为 I2C1 增加互斥量，避免总线访问冲突。"
    )


def section2():
    h1("2  系统总体设计")

    h2("2.1  硬件资源与接线")
    body(
        "STM32F103C8T6 最小系统板引出 PA、PB、PC 口，板载 PC13 LED 为低电平点亮。为了直观看到 3 s 周期的第二个 LED，"
        "本实验在 PB12 上外接一只 LED 和 330 Ω 限流电阻，接法为 PB12 → 330 Ω → LED 阳极，LED 阴极 → GND，因此 PB12 高电平点亮。"
        "AHT20 模块使用 3.3 V 供电，SCL 接 PB6，SDA 接 PB7；USART1 的 PA9 接 USB-TTL 的 RX，PA10 可接 TX，GND 必须共地。"
    )
    table(
        ["STM32F103C8T6", "外设", "方向 / 电平", "说明"],
        [
            ["PC13", "LED1", "输出，低电平亮", "板载 LED，1 s 周期"],
            ["PB12", "LED2", "输出，高电平亮", "外接 LED + 330 Ω，3 s 周期"],
            ["PB6", "AHT20 SCL", "复用开漏 AF_OD", "I2C1 SCL，100 kHz"],
            ["PB7", "AHT20 SDA", "复用开漏 AF_OD", "I2C1 SDA，100 kHz"],
            ["PA9", "USB-TTL RX", "复用推挽 AF_PP", "USART1 TX，115200"],
            ["PA10", "USB-TTL TX", "上拉输入", "USART1 RX，可只接 TX"],
            ["3.3 V / GND", "AHT20、LED、USB-TTL", "电源 / 地", "必须共地，AHT20 不要接 5 V 逻辑"],
        ],
        widths=[3.2, 4.0, 4.2, 4.0],
        cap="表 2-1  引脚分配",
    )
    figure("fig_wiring.png", 15.0, "图 2-1  硬件连接图")

    h2("2.2  软件分层")
    body(
        "移植后的软件分为应用层、uC/OS-III 内核层、Cortex-M3 移植层、CPU/LIB 层、STM32 HAL/BSP 层和硬件层。"
        "应用层只调用 OS 的任务、延时 API 和 BSP 驱动；移植层负责 PendSV 上下文切换、SysTick 节拍和临界区；"
        "HAL 层负责具体外设寄存器。分层的好处是应用代码不直接操作内核数据结构，换 MCU 时只需替换移植层和 HAL。"
    )
    figure("fig_arch.png", 14.2, "图 2-2  uC/OS-III 移植后的软件分层")

    h2("2.3  任务划分")
    body(
        "三个任务都采用“初始化一次 + 无限循环 + 周期延时”的结构。Task1 和 Task2 只控制 GPIO，执行时间在微秒级；"
        "Task3 的执行时间主要来自 AHT20 的 80 ms 转换等待和约 1 ms 的 I2C 传输，以及不到 10 ms 的串口发送。"
        "优先级按“LED 视觉实时性 > 传感器采集”分配：Task1 最高（4），Task2 次之（5），Task3 最低（6）。"
        "这样即使 Task3 正在读传感器，1 s 和 3 s 的 LED 边沿也不会被明显推迟。"
    )
    table(
        ["任务", "优先级", "栈大小", "周期", "阻塞方式", "共享资源"],
        [
            ["Start Task", "3", "512 B", "仅运行一次", "创建完任务后 OSTaskSuspend", "无"],
            ["Task1 LED1", "4", "512 B", "1 s", "OSTimeDlyHMSM 500 ms × 2", "GPIOC"],
            ["Task2 LED2", "5", "512 B", "3 s", "OSTimeDlyHMSM 1500 ms × 2", "GPIOB"],
            ["Task3 AHT20", "6", "1536 B", "2 s", "OSTimeDlyHMSM 2 s", "I2C1、USART1"],
            ["Tick Task", "10", "512 B", "1 ms", "内核内部", "节拍链表"],
            ["Idle Task", "15", "512 B", "空闲", "就绪表中无更高优先级任务时运行", "无"],
        ],
        widths=[2.4, 1.6, 3.0, 2.0, 4.0, 2.5],
        keep=True,
        cap="表 2-2  任务、优先级和栈分配",
    )
    note(
        "栈大小单位为 CPU_STK（STM32 上 1 个元素 = 4 字节）。Task3 使用浮点换算和 HAL I2C 调用，栈给到 1536 B；"
        "实际工程可通过 OSTaskStkChk() 查看剩余栈空间后再微调。"
    )

    h2("2.4  调度时序")
    body(
        "上电后三个任务几乎同时就绪。Task1 先运行，点亮 LED1 后延时 500 ms；Task2 接着点亮 LED2 后延时 1500 ms；"
        "Task3 最后运行，完成 AHT20 初始化后进入 2 s 周期。由于三个任务都很快进入阻塞态，CPU 大部分时间运行空闲任务，"
        "仅在 SysTick、I2C 传输和串口发送时被唤醒。图 2-3 给出三个任务的周期和相位关系。"
    )
    figure("fig_tasks.png", 15.4, "图 2-3  三个任务的周期与相位关系")
    body(
        "从图 2-3 可以看到：Task1 每 1 s 完成一次“亮—灭”，Task2 每 3 s 完成一次，二者在 t=3 s、6 s、9 s 处同时开始新一轮；"
        "Task3 每 2 s 产生一次串口突发，因此与 Task1 在偶数秒对齐，与 Task2 在 6 s 的整数倍对齐。"
        "这种相位关系不是强制同步，而是三个任务都从 t=0 开始延时自然形成的；如果需要严格同步，可以用事件标志或时间匹配延时。"
    )

def section3():
    h1("3  任务一：uC/OS-III 移植")

    h2("3.1  RTOS 基本概念")
    body(
        "实时操作系统（RTOS）与前后台程序的最大区别是“任务”与“调度”。每个任务是一个独立的无限循环函数，"
        "拥有自己的栈和任务控制块（TCB）；内核保存任务的优先级、状态、栈指针和延时信息，并在合适的时机切换 CPU。"
        "uC/OS-III 是抢占式、基于优先级的内核：高优先级任务一旦就绪，就会立即抢占低优先级任务；同优先级任务可以配置时间片轮转，"
        "本实验为了周期稳定，关闭了轮转调度。"
    )
    bullet("**任务（Task）**：独立的执行流，必须无限循环或结束时删除自己；本实验有三个应用任务。")
    bullet("**TCB**：保存任务栈指针、优先级、状态、延时剩余节拍、消息队列等；由 OSTaskCreate() 初始化。")
    bullet("**就绪表**：按优先级组织的位图/链表，调度器用 CLZ 指令快速找到最高优先级就绪任务。")
    bullet("**系统节拍（Tick）**：SysTick 每 1 ms 产生一次中断，OSTimeTick() 更新延时链表和超时。")
    bullet("**上下文切换**：PendSV 异常中保存当前任务的 R4–R11 和 PSP，切换到新任务的 PSP，再恢复寄存器。")
    bullet("**临界区**：CPU_SR_Save()/CPU_SR_Restore() 关中断保护内核链表，临界区应尽可能短。")
    bullet("**优先级反转**：低优先级任务持有互斥量、中优先级任务抢占时，高优先级任务被间接阻塞；uC/OS-III 的互斥量支持优先级继承。")

    h2("3.2  uC/OS-III 源码结构")
    body(
        "本工程使用 uC/OS-III V3.01.2 的 Cortex-M3 RealView 移植层，源码按功能分为配置、CPU、LIB、PORT 和内核五部分。"
        "为了避免 64 KB Flash 和 20 KB SRAM 不够用，只保留 RealView 一套移植文件，关闭了统计任务、定时器任务、"
        "中断延迟提交、时间戳和调试变量等非必要功能。"
    )
    table(
        ["目录", "主要文件", "作用"],
        [
            ["uCOS_CONFIG", "os_cfg.h, os_cfg_app.h, cpu_cfg.h, lib_cfg.h, app_cfg.h, includes.h", "内核功能裁剪、节拍/栈大小、应用任务参数"],
            ["uCOS_CPU", "cpu_core.c, cpu_core.h, cpu_def.h, cpu.h, cpu_a.asm, cpu_c.c", "CPU 底层：临界区、CLZ、NVIC 优先级、时间戳"],
            ["uCOS_III/Ports", "os_cpu.h, os_cpu_a.s, os_cpu_c.c", "Cortex-M3 移植：PendSV、SysTick、任务栈初始化"],
            ["uCOS_III/Source", "os_core.c, os_task.c, os_time.c, os_tick.c, os_prio.c ...", "内核源码：任务、调度、延时、事件、消息"],
            ["uCOS_LIB", "lib_ascii.c, lib_math.c, lib_mem.c, lib_str.c", "uC/LIB 通用库"],
        ],
        widths=[3.0, 8.0, 4.4],
        cap="表 3-1  uC/OS-III 源码目录",
    )
    body(
        "其中 os_cpu_a.s 是移植的核心：OSStartHighRdy() 负责启动第一个任务，OS_CPU_PendSVHandler() 负责保存/恢复上下文；"
        "os_cpu_c.c 提供 OSTaskStkInit()、OS_CPU_SysTickHandler() 和 OS_CPU_SysTickInit()；os_cpu.h 定义 OS_TASK_SW()、"
        "OSIntCtxSw()、OS_TS_GET() 等宏。"
    )

    h2("3.3  Cortex-M3 移植原理")
    body(
        "Cortex-M3 有两种栈指针：MSP（主栈）和 PSP（进程栈）。uC/OS-III 让中断和异常使用 MSP，让任务使用 PSP。"
        "每个任务创建时，OSTaskStkInit() 在任务栈顶伪造一个异常压栈帧，顺序与硬件异常自动压栈一致："
        "xPSR、PC、LR、R12、R3、R2、R1、R0，再手工保存 R11–R4。第一次切换时，PendSV 恢复这个帧，任务就从入口函数开始执行。"
    )
    body(
        "上下文切换由 PendSV 完成。PendSV 被设置为最低优先级，因此它不会打断任何中断，只会在所有中断处理完后执行。"
        "OSStartHighRdy() 先把 PSP 清 0、把 MSP 指向 OS_CPU_ExceptStkBase，再触发 PendSV；PendSV 看到 PSP=0，"
        "就知道是第一次运行，不需要保存旧任务，直接恢复最高优先级任务的栈帧。"
    )
    body(
        "系统节拍由 SysTick 提供。OS_CPU_SysTickInit(cnts) 设置 SysTick 重装值、优先级并使能中断；"
        "OS_CPU_SysTickHandler() 负责 OSIntEnter()、OSTimeTick() 和 OSIntExit()。如果启动文件仍然指向默认的 SysTick_Handler，"
        "或者没有把 SysTick 交给 OS，OSTimeDly() 就永远不会返回，这是移植中最常见的“卡死”原因。"
    )
    table(
        ["机制", "Cortex-M3 实现", "uC/OS-III 文件", "注意点"],
        [
            ["任务栈", "PSP 指向任务栈顶", "os_cpu_c.c: OSTaskStkInit", "栈帧必须与异常压栈顺序一致"],
            ["上下文切换", "PendSV 异常", "os_cpu_a.s: OS_CPU_PendSVHandler", "PendSV 优先级设为最低"],
            ["启动第一个任务", "OSStartHighRdy 触发 PendSV", "os_cpu_a.s: OSStartHighRdy", "PSP 先清 0"],
            ["系统节拍", "SysTick 中断", "os_cpu_c.c: OS_CPU_SysTickHandler", "必须由启动文件向量调用"],
            ["临界区", "PRIMASK 保存/恢复", "cpu_a.asm: CPU_SR_Save/Restore", "临界区尽量短"],
            ["中断嵌套", "OSIntEnter/OSIntExit", "os_core.c", "ISR 中调用 OS API 必须成对"],
        ],
        widths=[3.0, 5.0, 5.2, 4.2],
        cap="表 3-2  Cortex-M3 移植机制",
    )

    h2("3.4  移植步骤")
    h3("3.4.1  建立 HAL 基础工程")
    body(
        "先用 STM32CubeMX 或现成的 HAL 工程建立最小系统，确认在不加 RTOS 时 LED、串口和 AHT20 都能工作。"
        "这一步很重要：如果裸机程序就不通，加入 uC/OS 后很难判断是驱动问题还是移植问题。"
    )
    table(
        ["CubeMX 项目", "配置"],
        [
            ["RCC", "HSE = Crystal/Ceramic Resonator，PLL ×9，SYSCLK = 72 MHz"],
            ["Debug", "Serial Wire（保留 PA13/PA14，关闭 JTAG）"],
            ["GPIO", "PC13 输出（LED1），PB12 输出（LED2）"],
            ["I2C1", "I2C，100 kHz，PB6=SCL，PB7=SDA"],
            ["USART1", "Asynchronous，115200，8-N-1，PA9=TX，PA10=RX"],
            ["SysTick", "1 ms，HAL_Init() 默认配置"],
            ["Toolchain", "MDK-ARM，ARM Compiler 5（本工程使用 AC5）"],
        ],
        widths=[4.0, 11.4],
        cap="表 3-3  HAL 基础工程配置",
    )

    h3("3.4.2  加入 uC/OS-III 源码")
    body(
        "在工程根目录建立 uCOS_III 文件夹，把 uC/OS-III 的 Source、Ports/ARM-Cortex-M3/Generic/RealView、"
        "uC/CPU 的 ARM-Cortex-M3/RealView、uC/LIB 以及配置文件复制进去。Keil 中新建五个 Group："
        "uCOS_III_CONFIG、uCOS_III_CPU、uCOS_III_LIB、uCOS_III_PORT、uCOS_III_SOURCE，把 .c、.s、.asm 和头文件加入。"
        "注意头文件也要加入工程，方便在 Keil 中直接打开，但不参与编译。"
    )
    body(
        "Include Paths 需要包含 Core/Inc、HAL Inc、CMSIS Include、uCOS_CONFIG、uCOS_CPU、uCOS_CPU/ARM-Cortex-M3/RealView、"
        "uCOS_III/Ports/ARM-Cortex-M3/Generic/RealView、uCOS_III/Source、uCOS_LIB。"
        "宏定义使用 USE_HAL_DRIVER,STM32F103xB；C 语言选择 C99。"
    )

    h3("3.4.3  配置 os_cfg.h 和 os_cfg_app.h")
    body(
        "配置文件决定内核的功能和 RAM 占用。本实验保留任务管理、时间管理、信号量/队列/互斥量等基础模块，"
        "关闭统计任务、定时器任务、中断延迟提交、时间戳、应用钩子和调试变量，以适配 20 KB SRAM。"
        "关键配置如下表。"
    )
    table(
        ["宏", "值", "说明"],
        [
            ["OS_CFG_TICK_RATE_HZ", "1000", "1 ms 一个节拍，延时分辨率 1 ms"],
            ["OS_CFG_PRIO_MAX", "16", "支持 0–15 共 16 个优先级"],
            ["OS_CFG_TICK_TASK_PRIO", "10", "内核节拍任务优先级"],
            ["OS_CFG_IDLE_TASK_STK_SIZE", "128", "空闲任务栈 512 B"],
            ["OS_CFG_ISR_STK_SIZE", "128", "中断/异常栈 512 B"],
            ["OS_CFG_TASK_STK_LIMIT_PCT_EMPTY", "10", "栈剩余 10% 时报警"],
            ["OS_CFG_STAT_TASK_EN", "0", "关闭统计任务，节省 RAM"],
            ["OS_CFG_TMR_EN", "0", "关闭定时器任务"],
            ["OS_CFG_ISR_POST_DEFERRED_EN", "0", "关闭中断延迟提交，简化内核"],
            ["OS_CFG_TS_EN", "0", "关闭时间戳"],
            ["OS_CFG_APP_HOOKS_EN", "0", "关闭应用钩子"],
            ["OS_CFG_SCHED_ROUND_ROBIN_EN", "0", "关闭同优先级时间片轮转"],
        ],
        widths=[7.4, 2.2, 5.8],
        cap="表 3-4  os_cfg.h / os_cfg_app.h 关键配置",
    )
    body(
        "任务栈大小在 app_cfg.h 中定义：Start 128 字、LED1 128 字、LED2 128 字、AHT20 384 字。"
        "任务优先级分别为 3、4、5、6，均小于 OS_CFG_PRIO_MAX-1，避免创建失败。"
    )

    h3("3.4.4  修改启动文件和 SysTick")
    body(
        "这是移植的关键一步。STM32 的启动文件默认把 PendSV 向量指向 PendSV_Handler，把 SysTick 向量指向 SysTick_Handler。"
        "uC/OS-III 的上下文切换函数叫 OS_CPU_PendSVHandler，因此必须把向量表第 14 项改掉，并在汇编文件中 IMPORT 该符号；"
        "否则链接会报 A1516E: Bad symbol，或者运行后第一次任务切换就进 HardFault。"
    )
    code_block(
        r"""
; startup_stm32f103xb.s（修改前）
DCD     PendSV_Handler             ; PendSV Handler
DCD     SysTick_Handler            ; SysTick Handler

; startup_stm32f103xb.s（修改后）
IMPORT  OS_CPU_PendSVHandler
DCD     OS_CPU_PendSVHandler       ; uC/OS-III 上下文切换
DCD     SysTick_Handler            ; HAL tick + uC/OS-III tick
""",
        cap="代码 3-1  启动文件向量表修改",
    )
    body(
        "SysTick 仍然保留 SysTick_Handler 这个名字，但在 C 文件里先调用 HAL_IncTick()，再在 OS 已经运行时调用 "
        "OS_CPU_SysTickHandler()。这样 HAL_GetTick()/HAL_Delay() 和 uC/OS 的节拍都能工作；OSStart() 之前不会误入 OSTimeTick()。"
    )
    code_block(
        r"""
void SysTick_Handler(void)
{
    HAL_IncTick();

    if (OSRunning == OS_STATE_OS_RUNNING) {
        OS_CPU_SysTickHandler();
    }
}
""",
        cap="代码 3-2  SysTick 同时服务 HAL 和 uC/OS-III",
    )
    note(
        "不要在 SysTick_Handler 里再调用一次 OSTimeTick()，否则一个节拍会计数两次，所有周期都会减半。"
        "OS_CPU_SysTickHandler() 内部已经完成了 OSIntEnter、OSTimeTick 和 OSIntExit。"
    )

    h3("3.4.5  编写 OSInit / OSStart 启动流程")
    body(
        "main() 中先做 HAL 和板级初始化，再 OSInit()、创建起始任务、OSStart()。OSStart() 不会返回；"
        "在调用前关中断可以避免 SysTick 在第一个任务上下文建立之前进入内核。OSStartHighRdy() 最后会重新开中断。"
    )
    code_block(
        r"""
int main(void)
{
    OS_ERR err;

    HAL_Init();
    SystemClock_Config();
    MX_GPIO_Init();
    bsp_uart_init();
    bsp_i2c_init();

    App_Init();                 /* OSInit() + 创建 Start Task */

    __disable_irq();
    OSStart(&err);              /* 正常情况下不返回 */

    while (1) { }
}
""",
        cap="代码 3-3  main() 启动流程",
    )
    body(
        "起始任务在运行时才初始化 SysTick，因为此时 OS 已经建立好内部数据结构。"
        "OS_CPU_SysTickInit(SystemCoreClock / OSCfg_TickRate_Hz) 把 72 MHz / 1000 Hz = 72000 写入 SysTick 重装寄存器。"
        "随后 CPU_Init()、创建三个应用任务，最后 OSTaskSuspend() 挂起自己。"
    )
    code_block(
        r"""
void AppTaskStart(void *p_arg)
{
    OS_ERR err;
    (void)p_arg;

    OS_CPU_SysTickInit(SystemCoreClock / OSCfg_TickRate_Hz);
    CPU_Init();

    bsp_uart_puts("\r\n=== uC/OS-III + STM32F103C8T6 + AHT20 ===\r\n");
    AppTaskCreate();            /* 创建 LED1、LED2、AHT20 三个任务 */
    OSTaskSuspend(&AppTaskStartTCB, &err);
}
""",
        cap="代码 3-4  起始任务初始化节拍并创建应用任务",
    )

    h3("3.4.6  创建三个应用任务")
    body(
        "OSTaskCreate() 的参数较多，按顺序为：TCB、任务名、入口函数、参数、优先级、栈基址、栈警戒线、栈大小、"
        "消息队列长度、时间片、扩展指针、选项、错误码。栈警戒线一般取栈大小的 1/10；"
        "OS_OPT_TASK_STK_CHK | OS_OPT_TASK_STK_CLR 表示允许统计任务检查栈并清栈。"
    )
    code_block(
        r"""
OSTaskCreate(&AppTaskLed1TCB, "LED1 Task", AppTaskLed1, (void *)0,
             APP_TASK_LED1_PRIO, &AppTaskLed1Stk[0],
             APP_TASK_LED1_STK_SIZE / 10u, APP_TASK_LED1_STK_SIZE,
             0u, 0u, (void *)0,
             (OS_OPT)(OS_OPT_TASK_STK_CHK | OS_OPT_TASK_STK_CLR), &err);

OSTaskCreate(&AppTaskLed2TCB, "LED2 Task", AppTaskLed2, (void *)0,
             APP_TASK_LED2_PRIO, &AppTaskLed2Stk[0],
             APP_TASK_LED2_STK_SIZE / 10u, APP_TASK_LED2_STK_SIZE,
             0u, 0u, (void *)0,
             (OS_OPT)(OS_OPT_TASK_STK_CHK | OS_OPT_TASK_STK_CLR), &err);

OSTaskCreate(&AppTaskAht20TCB, "AHT20 Task", AppTaskAht20, (void *)0,
             APP_TASK_AHT20_PRIO, &AppTaskAht20Stk[0],
             APP_TASK_AHT20_STK_SIZE / 10u, APP_TASK_AHT20_STK_SIZE,
             0u, 0u, (void *)0,
             (OS_OPT)(OS_OPT_TASK_STK_CHK | OS_OPT_TASK_STK_CLR), &err);
""",
        cap="代码 3-5  创建三个应用任务",
    )
    body(
        "任务体使用 OSTimeDlyHMSM(..., OS_OPT_TIME_PERIODIC, ...) 做周期延时。PERIODIC 选项以“上一次唤醒时刻”为基准，"
        "会把任务执行时间扣除，因此周期不会随执行时间累积漂移；如果使用普通相对延时，周期会变成“执行时间 + 延时时间”。"
    )
    code_block(
        r"""
static void AppTaskLed1(void *p_arg)
{
    OS_ERR err;
    (void)p_arg;
    LED1_OFF();

    while (DEF_TRUE) {
        LED1_ON();
        OSTimeDlyHMSM(0, 0, 0, 500,
                      OS_OPT_TIME_HMSM_STRICT | OS_OPT_TIME_PERIODIC, &err);
        LED1_OFF();
        OSTimeDlyHMSM(0, 0, 0, 500,
                      OS_OPT_TIME_HMSM_STRICT | OS_OPT_TIME_PERIODIC, &err);
    }
}

static void AppTaskLed2(void *p_arg)
{
    OS_ERR err;
    (void)p_arg;
    LED2_OFF();

    while (DEF_TRUE) {
        LED2_ON();
        OSTimeDlyHMSM(0, 0, 1, 500,
                      OS_OPT_TIME_HMSM_STRICT | OS_OPT_TIME_PERIODIC, &err);
        LED2_OFF();
        OSTimeDlyHMSM(0, 0, 1, 500,
                      OS_OPT_TIME_HMSM_STRICT | OS_OPT_TIME_PERIODIC, &err);
    }
}
""",
        cap="代码 3-6  LED 任务的 1 s / 3 s 周期",
    )

    h3("3.4.7  编译与下载")
    body(
        "编译前确认 Device 为 STM32F103C8、IROM 0x08000000–0x0800FFFF、IRAM 0x20000000–0x20004FFF、"
        "编译器为 AC5、启动文件为 startup_stm32f103xb.s、PendSV 向量已经指向 OS_CPU_PendSVHandler。"
        "编译生成 Objects/RTOS_AHT20.hex，用 ST-Link 下载并复位。"
    )
    code_block(
        r"""
*** Using Compiler 'V5.06 update 5 (build 528)', folder: 'E:\KEIL5\ARM\ARMCC\Bin'
Build target 'RTOS_AHT20'
...
linking...
Program Size: Code=14088 RO-data=384 RW-data=76 ZI-data=8028
FromELF: creating hex file...
"Objects\RTOS_AHT20.axf" - 0 Error(s), 0 Warning(s).
""",
        cap="代码 3-7  Keil 编译输出",
    )
    body(
        "下载后如果 PC13 以 1 s 周期闪烁、PB12 以 3 s 周期闪烁，并且串口每 2 s 出现一行问候语和温湿度，说明移植成功。"
        "如果 LED 完全不闪，先用调试器暂停，查看是否停在 HardFault_Handler 或 OSStartHang；"
        "如果只有一个 LED 闪，检查任务优先级、栈大小和 OSTaskCreate 的返回值。"
    )

    h2("3.5  移植中的问题与解决")
    table(
        ["现象", "原因", "解决方法"],
        [
            ["编译报 A1516E: Bad symbol 'OS_CPU_PendSVHandler'", "启动文件只写了 DCD，没有 IMPORT 外部符号", "在向量表前加 IMPORT OS_CPU_PendSVHandler"],
            ["编译报 A1167E: Invalid line start", "startup 文件被保存成带 BOM 的 UTF-8，armasm 不识别 BOM", "用无 BOM 的 UTF-8/ASCII 重新保存"],
            ["下载后停在 OSStartHang", "PendSV 向量仍指向默认 PendSV_Handler", "把向量改为 OS_CPU_PendSVHandler"],
            ["OSTimeDly 不返回 / 所有任务只跑一次", "SysTick 没有调用 OS_CPU_SysTickHandler", "在 SysTick_Handler 中调用，或直接把向量指向 OS handler"],
            ["进入 HardFault", "任务栈太小、栈溢出、栈帧未 8 字节对齐", "增大栈、检查 OSTaskStkInit、确认 CPU_STK 为 32 位"],
            ["Task3 创建失败", "优先级 ≥ OS_CFG_PRIO_MAX 或栈小于 OS_CFG_STK_SIZE_MIN", "调整优先级和栈大小，检查 OSTaskCreate 的 err"],
            ["HAL_Delay 导致 LED 卡顿", "HAL_Delay 忙等，不让出 CPU", "RTOS 任务中改用 OSTimeDlyHMSM；AHT20 驱动用延时钩子"],
            ["串口中文乱码", "源码 UTF-8，串口助手按 GBK 解码", "串口助手设为 UTF-8，或改成英文调试信息"],
            ["AC6 编译 os_cpu_a.s 报语法错误", "RealView 汇编是 armasm 语法，不是 GNU 语法", "使用 AC5，或改用 GNU 移植文件"],
            ["RAM 不够 / 链接溢出", "任务栈、ISR 栈、堆设置过大", "关闭统计/定时器任务，减小栈，关闭 lib_mem 堆"],
        ],
        widths=[5.4, 5.4, 5.2],
        cap="表 3-5  uC/OS-III 移植常见问题",
    )

def section4():
    h1("4  任务二：I2C 总线与 AHT20")

    h2("4.1  I2C 总线协议")
    body(
        "I2C（Inter-Integrated Circuit）是两线制同步串行总线，只有 SCL（时钟）和 SDA（数据）两根信号线。"
        "两根线都是开漏输出，必须通过上拉电阻接到电源，因此空闲时都是高电平；多个设备可以并联在同一条总线上，"
        "通过 7 位地址区分。主机产生时钟和起始/停止条件，从机在地址匹配后应答。"
    )
    bullet("**起始条件（START）**：SCL 为高时，SDA 由高变低。")
    bullet("**停止条件（STOP）**：SCL 为高时，SDA 由低变高。")
    bullet("**数据有效**：SCL 为高期间 SDA 必须稳定，数据在 SCL 高电平期间被采样；SDA 只能在 SCL 低电平期间改变。")
    bullet("**应答（ACK）**：每传输 8 位（1 字节）后，第 9 个时钟由接收方把 SDA 拉低表示 ACK；不拉低表示 NACK。")
    bullet("**地址**：7 位地址 + 1 位 R/W（0 写，1 读），共 8 位；例如 AHT20 地址 0x38，写帧为 0x70，读帧为 0x71。")
    bullet("**时钟拉伸**：从机来不及处理时可以把 SCL 拉低，主机必须等待；AHT20 一般不拉伸，但协议允许。")
    bullet("**仲裁**：多主机同时发送时，靠 SDA 线与特性逐位仲裁，输掉的主机自动退出。")
    table(
        ["参数", "标准模式（100 kHz）", "说明"],
        [
            ["SCL 频率", "≤ 100 kHz", "本实验配置 100 kHz"],
            ["SCL 周期", "10 µs", "高电平约 5 µs，低电平约 5 µs"],
            ["START 建立时间 tSU;STA", "≥ 4.7 µs", "SCL 变高到 SDA 下降之间"],
            ["START 保持时间 tHD;STA", "≥ 4.0 µs", "START 后 SCL 保持低至少 4.0 µs"],
            ["STOP 建立时间 tSU;STO", "≥ 4.0 µs", "SCL 变高到 SDA 上升之间"],
            ["数据建立时间 tSU;DAT", "≥ 250 ns", "SDA 变化到 SCL 上升沿"],
            ["数据保持时间 tHD;DAT", "≥ 0 µs（Fast 模式 ≥ 0.3 µs）", "SCL 下降沿后 SDA 保持"],
            ["总线空闲时间 tBUF", "≥ 4.7 µs", "STOP 到下一个 START"],
        ],
        widths=[5.4, 4.8, 5.6],
        cap="表 4-1  I2C 标准模式时序参数",
    )
    body(
        "一次完整的写事务为：START → 地址字节（7 位地址 + W）→ ACK → 数据字节 1 → ACK → … → 数据字节 n → ACK → STOP。"
        "读事务为：START → 地址字节（7 位地址 + R）→ ACK → 数据字节 1 → ACK → … → 最后一个数据字节 → NACK → STOP。"
        "主机必须在最后一个字节给出 NACK，告诉从机停止发送。"
    )

    h2("4.2  软件 I2C 与硬件 I2C")
    body(
        "野火教材第 23 章“I2C——读写 EEPROM”把 I2C 的实现分为软件模拟和硬件外设两种。软件 I2C 用 GPIO 手动翻转 SCL/SDA，"
        "按协议逐位发送；硬件 I2C 使用 MCU 内部的 I2C 外设，只需写数据寄存器并等待状态标志。两者没有本质协议差别，"
        "区别在时序产生方式、CPU 占用、引脚灵活性和调试难度。"
    )
    table(
        ["对比项", "软件 I2C（GPIO 模拟）", "硬件 I2C（I2C1 外设）"],
        [
            ["实现方式", "GPIO 开漏输出，代码控制 SCL/SDA 和延时", "配置 CCR/TRISE，写 DR，硬件产生 START/ACK/STOP"],
            ["引脚", "任意 GPIO，可灵活改线", "固定复用引脚，F103 为 PB6/PB7 或重映射"],
            ["速率", "受 CPU 和中断影响，通常 ≤ 100 kHz", "可稳定到 100 kHz/400 kHz"],
            ["CPU 占用", "高，逐位延时和翻转", "低，硬件移位和 ACK"],
            ["时序精度", "依赖软件延时，中断会破坏时序", "硬件保证，受 PCLK 精度影响"],
            ["错误处理", "需要自己判断 ACK/超时", "SR1/SR2 提供 AF、BERR、ARLO、BUSY 等标志"],
            ["调试", "逻辑分析仪容易看懂，代码可单步", "外设状态多，BUSY 卡死时排查较复杂"],
            ["本实验", "未使用，作为原理对照", "使用 I2C1，100 kHz，HAL 阻塞收发"],
        ],
        widths=[3.2, 6.2, 6.2],
        cap="表 4-2  软件 I2C 与硬件 I2C 的对比",
    )
    body(
        "软件 I2C 的优点是“任何引脚都能用、时序完全可控”，适合引脚受限或需要特殊时序的场合；缺点是占用 CPU，"
        "而且在 RTOS 中如果延时被高优先级任务打断，SCL 高/低时间会变长，虽然 I2C 允许从机等待，但高速时容易出错。"
        "硬件 I2C 把移位、ACK、START/STOP 都交给外设，CPU 只在传输开始/结束时参与，因此本实验选择硬件 I2C。"
    )

    h2("4.3  STM32F1 硬件 I2C 配置")
    body(
        "STM32F103 的 I2C1 挂在 APB1 上，PB6/PB7 需要配置为复用开漏（GPIO_MODE_AF_OD），外部接 4.7 kΩ 上拉。"
        "HAL 初始化时设置 ClockSpeed=100000、DutyCycle=I2C_DUTYCYCLE_2、7 位地址、关闭双地址、关闭通用呼叫、"
        "关闭时钟拉伸。在 36 MHz PCLK1 下，标准模式 CCR = 36 MHz/(2×100 kHz) = 180，TRISE = 36+1 = 37。"
    )
    code_block(
        r"""
hi2c1.Instance = I2C1;
hi2c1.Init.ClockSpeed = 100000U;
hi2c1.Init.DutyCycle = I2C_DUTYCYCLE_2;
hi2c1.Init.OwnAddress1 = 0;
hi2c1.Init.AddressingMode = I2C_ADDRESSINGMODE_7BIT;
hi2c1.Init.DualAddressMode = I2C_DUALADDRESS_DISABLE;
hi2c1.Init.OwnAddress2 = 0;
hi2c1.Init.GeneralCallMode = I2C_GENERALCALL_DISABLE;
hi2c1.Init.NoStretchMode = I2C_NOSTRETCH_DISABLE;
HAL_I2C_Init(&hi2c1);
""",
        cap="代码 4-1  I2C1 初始化（bsp_i2c.c）",
    )
    body(
        "HAL 的阻塞收发接口为 HAL_I2C_Master_Transmit() 和 HAL_I2C_Master_Receive()。传入的地址是 7 位地址左移一位，"
        "即 0x38<<1 = 0x70；HAL 根据读/写自动设置最低位。发送完成会返回 HAL_OK，失败返回 HAL_ERROR/HAL_TIMEOUT，"
        "驱动里会把连续错误计数，达到 3 次时执行总线恢复。"
    )
    body(
        "总线恢复的流程是：HAL_I2C_DeInit → 把 PB6/PB7 当普通开漏 GPIO → SDA 释放为高 → 手动发 9 个 SCL 时钟 → "
        "产生一个 STOP → HAL_I2C_Init。这样可以把“从机在传输中途掉电，一直拉低 SDA”导致的总线死锁解开。"
        "本实验的 AHT20 一般不会死锁，但保留该机制可以提高长时间运行的可靠性。"
    )

    h2("4.4  AHT20 数据手册要点")
    body(
        "AHT20 是奥松电子的数字温湿度传感器，内部集成电容式湿度敏感元件和带隙温度敏感元件，出厂校准，"
        "通过 I2C 输出 20 位湿度原始值和 20 位温度原始值。模块通常自带稳压和上拉，直接 3.3 V 供电即可。"
    )
    table(
        ["项目", "参数 / 说明"],
        [
            ["供电电压", "2.0–5.5 V（模块通常 3.3 V）"],
            ["通信接口", "I2C，最高 400 kHz，7 位地址 0x38"],
            ["温度范围 / 精度", "-40–85 ℃，典型 ±0.3 ℃"],
            ["湿度范围 / 精度", "0–100 %RH，典型 ±2 %RH"],
            ["转换时间", "约 80 ms（典型）"],
            ["上电等待", "≥ 40 ms"],
            ["数据长度", "7 字节：status + hum20 + temp20 + CRC8"],
            ["CRC", "多项式 0x31，初值 0xFF，校验前 6 字节"],
        ],
        widths=[4.4, 11.0],
        cap="表 4-3  AHT20 主要参数",
    )
    table(
        ["命令", "字节序列", "作用"],
        [
            ["初始化 / 校准", "0xBE 0x08 0x00", "status.bit3=0 时发送，等待 10 ms"],
            ["触发测量", "0xAC 0x33 0x00", "触发一次温湿度转换，等待 80 ms"],
            ["软复位", "0xBA", "复位传感器（本程序未使用）"],
            ["读状态", "0x71 + 1 字节", "bit7=忙，bit3=已校准"],
            ["读数据", "0x71 + 7 字节", "status + 湿度 20 bit + 温度 20 bit + CRC"],
        ],
        widths=[4.2, 5.0, 6.2],
        cap="表 4-4  AHT20 常用命令",
    )
    body(
        "状态字节的 bit7 是忙标志：1 表示转换未完成，0 表示可以读数据；bit3 是校准标志：1 表示已校准，"
        "0 表示需要发送 0xBE 0x08 0x00 初始化。上电后先等待 40 ms，再读状态；如果 bit3=0，发送初始化命令并等待 10 ms。"
        "之后每次测量：发送 0xAC 0x33 0x00，等待 80 ms，读 7 字节，检查 bit7=0 后再换算。"
    )
    body(
        "7 字节数据的格式为：data[0]=status，data[1..3] 的高 20 位是湿度，data[3] 的低 4 位 + data[4..5] 是温度，"
        "data[6] 是 CRC8。湿度原始值："
    )
    code_block(
        r"""
humidity_raw = ((uint32_t)data[1] << 12) |
               ((uint32_t)data[2] << 4)  |
               ((uint32_t)data[3] >> 4);

temperature_raw = ((uint32_t)(data[3] & 0x0F) << 16) |
                  ((uint32_t)data[4] << 8) |
                  (uint32_t)data[5];

humidity    = humidity_raw * 100.0f / 1048576.0f;          // %RH
temperature = temperature_raw * 200.0f / 1048576.0f - 50.0f; // ℃
""",
        cap="代码 4-2  AHT20 数据换算",
    )
    body(
        "例如读到 `18 80 00 06 00 00 23`：status=0x18（bit7=0、bit3=1），湿度原始值 0x80000，"
        "湿度 = 0x80000/2^20×100 = 50.0 %RH；温度原始值 0x60000，温度 = 0x60000/2^20×200−50 = 25.0 ℃；"
        "CRC8 对前 6 字节计算得到 0x23，与 data[6] 一致，数据有效。"
    )
    figure("fig_aht20_flow.png", 14.0, "图 4-1  AHT20 初始化与测量流程")

    h2("4.5  AHT20 驱动实现")
    body(
        "驱动分为三层：bsp_i2c.c 负责 I2C1 初始化和字节收发，aht20.c 负责命令、状态、CRC 和换算，app.c 负责任务周期和串口输出。"
        "这样的分层让裸机程序和 RTOS 程序可以共用同一个 AHT20 驱动，只需要替换延时函数。"
    )
    body(
        "AHT20 的等待时间（40 ms、10 ms、80 ms、20 ms）不能直接用 HAL_Delay()，因为 HAL_Delay() 是忙等，"
        "会阻塞同优先级和低优先级任务。驱动内部调用 `aht20_delay_ms()`：裸机时使用 __weak 的 HAL_Delay 版本，"
        "RTOS 工程在 app.c 中提供强定义，改用 OSTimeDlyHMSM() 让出 CPU。"
    )
    code_block(
        r"""
/* aht20.c：弱定义，裸机默认使用 HAL_Delay */
__weak void aht20_delay_ms(uint32_t ms)
{
    HAL_Delay(ms);
}

/* app.c：RTOS 强定义，让出 CPU */
void aht20_delay_ms(uint32_t ms)
{
    OS_ERR err;
    if (OSRunning == OS_STATE_OS_RUNNING) {
        OSTimeDlyHMSM(0, 0, 0, ms,
                      OS_OPT_TIME_HMSM_STRICT, &err);
    } else {
        HAL_Delay(ms);
    }
}
""",
        cap="代码 4-3  AHT20 延时钩子",
    )
    code_block(
        r"""
bool aht20_init(void)
{
    uint8_t status = 0;

    aht20_delay_ms(40);                         /* 上电等待 ≥40 ms */

    if (!bsp_i2c_read(AHT20_I2C_ADDR, &status, 1, 50)) {
        s_last_status = 0xFFU;
        return false;
    }
    s_last_status = status;

    if ((status & 0x08U) == 0U) {               /* bit3=0：未校准 */
        uint8_t cmd[3] = {0xBEU, 0x08U, 0x00U};
        if (!bsp_i2c_write(AHT20_I2C_ADDR, cmd, sizeof(cmd), 50)) {
            return false;
        }
        aht20_delay_ms(10);
    }
    return true;
}
""",
        cap="代码 4-4  AHT20 初始化",
    )
    code_block(
        r"""
bool aht20_read(aht20_data_t *out)
{
    uint8_t cmd[3] = {0xACU, 0x33U, 0x00U};
    uint8_t data[7] = {0};
    bool got = false;

    if (out == NULL) return false;
    out->valid = 0;
    out->crc_ok = 0;

    if (!bsp_i2c_write(AHT20_I2C_ADDR, cmd, sizeof(cmd), 50))
        return false;

    for (uint8_t attempt = 0; attempt < 3U; ++attempt) {
        aht20_delay_ms(80);                     /* 转换时间 */
        if (!bsp_i2c_read(AHT20_I2C_ADDR, data, sizeof(data), 100))
            return false;

        s_last_status = data[0];
        if ((data[0] & 0x80U) == 0U) {          /* bit7=0：转换完成 */
            got = true;
            break;
        }
        aht20_delay_ms(20);
    }
    if (!got) return false;

    uint32_t humidity_raw = ((uint32_t)data[1] << 12) |
                            ((uint32_t)data[2] << 4)  |
                            ((uint32_t)data[3] >> 4);
    uint32_t temperature_raw = ((uint32_t)(data[3] & 0x0FU) << 16) |
                               ((uint32_t)data[4] << 8) |
                               (uint32_t)data[5];

    out->humidity = ((float)humidity_raw * 100.0f) / 1048576.0f;
    out->temperature = (((float)temperature_raw * 200.0f) / 1048576.0f) - 50.0f;
    out->crc_ok = (crc8(data, 6) == data[6]) ? 1U : 0U;
    out->valid = 1U;
    return true;
}
""",
        cap="代码 4-5  AHT20 触发测量与读取",
    )
    body(
        "CRC8 的实现为：初值 0xFF，逐字节异或，然后逐位判断最高位，若为 1 则左移并异或 0x31，否则只左移。"
        "对前 6 字节计算，结果与 data[6] 比较。CRC 错误时本程序仍然显示温湿度，但标记 CRC=ERR，便于判断是接线干扰还是模块问题。"
    )

    h2("4.6  任务三集成")
    body(
        "Task3 在进入循环前调用一次 aht20_init()，之后每 2 s 执行一次“发送问候语 → 读传感器 → 输出温湿度 → 周期延时”。"
        "问候语使用题目要求的原文 `hello uc/OS! 欢迎来到RTOS多任务环境！`，温湿度用自定义的一位小数输出，不依赖 printf，"
        "避免引入大体积的浮点格式化库。"
    )
    code_block(
        r"""
static void AppTaskAht20(void *p_arg)
{
    OS_ERR err;
    aht20_data_t data;
    bool init_ok;

    (void)p_arg;
    init_ok = aht20_init();

    while (DEF_TRUE) {
        bsp_uart_puts("hello uc/OS! 欢迎来到RTOS多任务环境！\r\n");

        if (aht20_read(&data)) {
            bsp_uart_puts("[TASK3] AHT20: T=");
            uart_put_1dec(data.temperature);
            bsp_uart_puts(" C, RH=");
            uart_put_1dec(data.humidity);
            bsp_uart_puts(" %, CRC=");
            bsp_uart_puts(data.crc_ok ? "OK" : "ERR");
            bsp_uart_puts("\r\n");
        } else {
            bsp_uart_puts("[TASK3] AHT20 read failed, status=0x");
            bsp_uart_put_hex8(aht20_last_status());
            bsp_uart_puts("\r\n");
        }

        OSTimeDlyHMSM(0, 0, 2, 0,
                      OS_OPT_TIME_HMSM_STRICT | OS_OPT_TIME_PERIODIC, &err);
    }
}
""",
        cap="代码 4-6  Task3 每 2 s 采集并输出",
    )
    body(
        "这里的 OSTimeDlyHMSM 使用 PERIODIC 选项，2 s 的基准是上一次唤醒时刻，不是“读完传感器后再等 2 s”。"
        "因此即使一次测量花了 80–100 ms，任务仍然是严格的 2 s 起始周期，不会累积成 2.1 s、2.2 s。"
    )

    h2("4.7  串口输出")
    body(
        "USART1 配置为 115200-8-N-1，PA9 为 TX，PA10 为 RX。bsp_uart.c 使用 HAL_UART_Transmit() 阻塞发送，"
        "每帧数据不超过 100 字节，在 115200 下约 8.7 ms 发完，对 2 s 周期影响很小。"
        "串口助手需要选择 UTF-8 编码，否则中文问候语会显示为乱码。"
    )
    figure("fig_serial.png", 15.2, "图 4-2  串口输出格式示例（非实物截图）")
    note(
        "图 4-2 是按程序格式化逻辑生成的输出示例，用于说明每 2 s 的输出顺序和字段；实物截图请用你自己的串口助手替换。"
    )

    h2("4.8  示波器 / 逻辑分析仪观察")
    h3("4.8.1  测量连接与触发")
    body(
        "把示波器 CH1 的 10× 探头接 PB6（SCL），CH2 接 PB7（SDA），地线夹接板子 GND。两个通道都设为 3.3 V 逻辑、"
        "DC 耦合、1 V/div；时间基准先设 20 µs/div，触发源选 CH2（SDA），触发方式为下降沿，触发电平约 1.6 V，"
        "单次触发。按复位后应能抓到 AHT20 初始化或测量帧。若要观察 80 ms 的转换间隔，把时间基准改为 20 ms/div。"
        "使用逻辑分析仪时，采样率至少 1 MHz（推荐 4–24 MHz），并开启 I2C 解码，7 位地址设为 0x38。"
    )
    body(
        "本报告没有把 Keil 的虚拟逻辑分析仪作为定量依据。Keil Logic Analyzer 通过 SWD/JTAG 读取变量或外设寄存器，"
        "采样率受调试接口和 IDE 刷新限制，通常只有毫秒级；而 100 kHz I2C 的一位只有 10 µs，用它会严重欠采样，"
        "看到的“波形”不能用于判断 START/ACK。若只有 Keil，可以把 I2C 降到 10 kHz 以下、只观察 GPIOB->IDR 的 bit6/bit7 变化，"
        "但这只能做定性演示，不能替代示波器或外部逻辑分析仪。"
    )

    h3("4.8.2  时序重绘与分析")
    body(
        "图 4-3 是按本程序实际配置（100 kHz 标准模式）和实际帧内容重绘的 I2C 波形，不是实物示波器截图。"
        "图中上、下两个面板分别对应初始化写命令帧和测量读数据帧；SCL 的一个完整周期为 10 µs，SDA 在 SCL 低电平期间改变，"
        "在 SCL 高电平期间被采样。"
    )
    figure("fig_i2c_wave.png", 15.4, "图 4-3  AHT20 I2C 时序重绘（100 kHz，非实物截图）")
    body(
        "从图 4-3 可以直接读出以下协议要素：起始条件为 SCL 高时 SDA 下降；地址字节 0x70 的 8 位为 0111 0000，"
        "第 9 个时钟从机拉低 SDA 给出 ACK；随后依次发送 0xBE、0x08、0x00，每个字节后都有 ACK；最后 SCL 高时 SDA 上升形成 STOP。"
        "读帧的地址字节为 0x71（0111 0001），从机 ACK 后连续输出 7 个字节，主机对前 6 个字节回 ACK，对最后一个字节回 NACK，然后 STOP。"
    )
    table(
        ["阶段", "理论/配置值", "你的实测值（填写）", "备注"],
        [
            ["SCL 频率", "100.0 kHz", "", "标准模式上限 100 kHz"],
            ["SCL 周期", "10.0 µs", "", "高约 5 µs，低约 5 µs"],
            ["START 建立时间", "≥ 4.7 µs", "", "SCL 高时 SDA 下降前"],
            ["地址帧（8+ACK）", "9 个时钟，约 90 µs", "", "0x70 或 0x71"],
            ["初始化写帧总时长", "约 370 µs", "", "START+36 时钟+STOP"],
            ["测量写帧总时长", "约 370 µs", "", "START+36 时钟+STOP"],
            ["读 7 字节帧总时长", "约 735 µs", "", "START+72 时钟+STOP"],
            ["写命令到读数据间隔", "约 80 ms", "", "AHT20 转换时间"],
            ["ACK 电平", "低电平，接近 0 V", "", "从机拉低 SDA"],
            ["空闲电平", "SCL/SDA 均为 3.3 V", "", "上拉电阻作用"],
        ],
        widths=[5.0, 4.4, 3.8, 4.2],
        cap="表 4-5  I2C 时序记录表（理论值与实测填写）",
    )
    note(
        "表中“理论/配置值”由 100 kHz 时钟和帧长计算得到；实测值请用示波器游标或逻辑分析仪测量后填写。"
        "不同上拉电阻、探头电容和杜邦线长度会造成上升沿和周期略有差异，但地址、命令、ACK 和 STOP 的顺序必须与图 4-3 一致。"
    )

    h3("4.8.3  地址与命令的对照结论")
    body(
        "**模块的 I2C 地址是多少？** AHT20 的数据手册规定 7 位地址为 0x38。程序中的 `AHT20_I2C_ADDR` 就是 0x38；"
        "HAL 库要求传入左移一位的地址，所以写操作在线路上表现为 0x70（0111 0000），读操作表现为 0x71（0111 0001）。"
        "用逻辑分析仪解码时，软件通常显示 7 位地址 0x38，并把 R/W 位单独标出。"
    )
    body(
        "**程序在初始化阶段发送了什么命令？** 上电等待 40 ms 后，程序先读 1 字节状态。如果 status.bit3=0（未校准），"
        "发送 3 字节命令 `0xBE 0x08 0x00`，然后等待 10 ms；如果 bit3=1，跳过该命令。之后每次测量发送 "
        "`0xAC 0x33 0x00` 触发转换，等待 80 ms，再读 7 字节。初始化阶段不会发送 0xAC；0xAC 属于测量阶段。"
    )
    table(
        ["帧", "线上字节（含地址）", "方向", "说明"],
        [
            ["读状态", "START, 0x71, ACK, status, NACK, STOP", "主机读", "判断 bit7/bit3"],
            ["初始化（条件）", "START, 0x70, ACK, 0xBE, ACK, 0x08, ACK, 0x00, ACK, STOP", "主机写", "仅 bit3=0 时"],
            ["触发测量", "START, 0x70, ACK, 0xAC, ACK, 0x33, ACK, 0x00, ACK, STOP", "主机写", "每 2 s 一次"],
            ["读数据", "START, 0x71, ACK, d0..d6, NACK, STOP", "主机读", "7 字节 + CRC"],
        ],
        widths=[3.2, 9.0, 2.4, 3.0],
        cap="表 4-6  AHT20 初始化与测量帧",
    )

    h2("4.9  I2C 调试中的问题与解决")
    table(
        ["现象", "可能原因", "解决方法"],
        [
            ["HAL_I2C_Master_Transmit 返回 HAL_ERROR", "从机无 ACK：地址错、没供电、SDA/SCL 接反", "查 3.3 V/GND、PB6/PB7、地址 0x38；用 bsp_i2c_scan() 扫描"],
            ["总线一直 BUSY", "从机在传输中掉电，拉低 SDA", "执行 9 个 SCL + STOP 的总线恢复；检查上拉"],
            ["读回 0xFF 或 0x00", "没有等待 80 ms、status.bit7 仍为 1、命令没发出去", "确认 0xAC 0x33 0x00 已发送，按 bit7 重试读取"],
            ["温湿度不变或明显异常", "初始化未完成、CRC 错误、模块损坏", "读 status.bit3；检查 CRC；换模块对比"],
            ["CRC 一直 ERR", "杜邦线过长/干扰、读长度不对、CRC 算法错", "缩短线、降低到 100 kHz、核对多项式 0x31/初值 0xFF"],
            ["中文乱码", "串口助手用 GBK 解码 UTF-8 字符串", "设为 UTF-8；或把问候语改成英文"],
            ["I2C 偶尔失败", "上拉太弱、电源不稳、地线干扰", "4.7 kΩ 上拉、加 0.1 µF 去耦、共地、缩短线"],
            ["PB6/PB7 无波形", "GPIO 没配 AF_OD、I2C1 时钟没开、引脚被其他外设占用", "检查 HAL_I2C_MspInit 和 __HAL_RCC_I2C1_CLK_ENABLE"],
        ],
        widths=[4.8, 6.0, 5.2],
        keep=True,
        cap="表 4-7  I2C/AHT20 常见问题",
    )

def section5():
    h1("5  实验结果与分析")

    h2("5.1  编译结果")
    body(
        "工程在 Keil MDK 5.24a + ARMCC 5.06 下编译，0 Error、0 Warning，生成的 HEX 文件位于 `flash/RTOS_AHT20.hex`。"
        "资源占用如下表。14.2 KB 的 Flash 和 7.9 KB 的 RAM 对 64 KB/20 KB 的 STM32F103C8T6 来说比较宽裕，"
        "后续增加 OLED、DMA 或更多任务仍有空间。"
    )
    table(
        ["项目", "大小", "占比 / 说明"],
        [
            ["Code", "14088 B", "约 13.8 KB"],
            ["RO-data", "384 B", "常量、字符串"],
            ["RW-data", "76 B", "已初始化全局变量"],
            ["ZI-data", "8028 B", "含任务栈、ISR 栈、启动栈、堆"],
            ["Flash 合计", "14548 B", "约 22.2% / 64 KB"],
            ["RAM 合计", "8104 B", "约 39.6% / 20 KB"],
        ],
        widths=[4.0, 4.0, 7.4],
        cap="表 5-1  编译资源占用",
    )
    note(
        "本报告编写环境没有连接实验板和示波器，因此 5.2、5.3 的“实测”列留空，图 4-3 为按 100 kHz 协议重绘的时序图，"
        "图 4-2 为串口输出格式示例；代码、HEX 和 Keil 工程均已实际编译通过。请烧录后用你的串口助手和示波器补填实测数据。"
    )

    h2("5.2  LED 与任务周期")
    body(
        "用示波器 CH1 接 PC13、CH2 接 PB12，时间基准 500 ms/div，可以同时看到两路 LED 的包络。"
        "Task1 的周期应为 1.000 s，正脉宽（低电平点亮）约 0.500 s；Task2 的周期应为 3.000 s，正脉宽约 1.500 s。"
        "由于 OSTimeDlyHMSM 的 PERIODIC 选项以唤醒时刻为基准，任务执行时间（GPIO 翻转只有微秒级）不会造成周期累积误差；"
        "实测抖动主要来自 SysTick 中断延迟和示波器触发，通常在 ±1 ms 以内。"
    )
    table(
        ["测量项", "设计值", "实测值（填写）", "误差 / 备注"],
        [
            ["LED1 周期", "1.000 s", "", "PC13，低电平亮"],
            ["LED1 高电平时间（灭）", "0.500 s", "", "占空比约 50%"],
            ["LED1 低电平时间（亮）", "0.500 s", "", "占空比约 50%"],
            ["LED2 周期", "3.000 s", "", "PB12，高电平亮"],
            ["LED2 高电平时间（亮）", "1.500 s", "", "占空比约 50%"],
            ["LED2 低电平时间（灭）", "1.500 s", "", "占空比约 50%"],
            ["Task3 串口间隔", "2.000 s", "", "问候语到下一帧问候语"],
        ],
        widths=[5.2, 4.0, 4.2, 4.6],
        cap="表 5-2  LED 与任务周期记录表",
    )
    body(
        "如果 LED1 周期是 0.5 s 而不是 1 s，通常是把“亮 500 ms + 灭 500 ms”误写成了只延时一次 500 ms；"
        "如果 LED2 周期是 1.5 s，检查是否把 1500 ms 写成了 750 ms。若两个 LED 的周期都减半，检查 SysTick 是否被重复计数"
        "（例如 SysTick_Handler 里又调用了一次 OSTimeTick）。"
    )

    h2("5.3  串口与温湿度")
    body(
        "串口助手设置为 115200-8-N-1、UTF-8 后，每 2 s 应看到一组“问候语 + 温湿度”输出。正常帧的 T 在室温附近，"
        "RH 在环境湿度附近，CRC=OK；如果传感器未接，TASK3 会打印 init FAILED 或 read failed，但不会死机，"
        "因为驱动对 I2C 错误做了返回和重试。"
    )
    figure("fig_serial.png", 15.2, "图 5-1  串口输出格式示例（非实物截图）")
    table(
        ["次数", "时间戳", "温度 / ℃", "湿度 / %RH", "CRC", "备注"],
        [
            ["1", "", "", "", "OK", "上电第一帧"],
            ["2", "", "", "", "OK", "2 s 后"],
            ["3", "", "", "", "OK", "4 s 后"],
            ["4", "", "", "", "OK", "6 s 后"],
            ["5", "", "", "", "OK", "8 s 后"],
        ],
        widths=[1.6, 3.2, 3.2, 3.4, 1.8, 4.2],
        cap="表 5-3  温湿度实测记录表（烧录后填写）",
    )
    body(
        "从数据手册的换算公式看，20 位原始值的分辨率为 1/2^20，对应温度约 0.00019 ℃、湿度约 0.000095 %RH，"
        "远高于传感器本身的精度，因此串口只保留一位小数。温湿度的绝对误差主要来自传感器精度（典型 ±0.3 ℃、±2 %RH）"
        "和模块自热，而不是 I2C 传输。"
    )

    h2("5.4  实时性分析")
    body(
        "三个任务的 CPU 占用都很低：Task1/Task2 只在唤醒时翻转 GPIO，执行时间几微秒；Task3 每 2 s 执行一次，"
        "其中 AHT20 转换等待 80 ms 是阻塞延时，不占 CPU；I2C 传输约 1 ms；串口输出约 5–10 ms。"
        "按最坏情况估算，Task3 每 2 s 占用 CPU 约 10 ms，CPU 负载小于 1%；加上 SysTick 和内核调度，系统大部分时间在空闲任务。"
    )
    body(
        "优先级设计保证了 LED 的边沿不被传感器任务延迟：Task1 优先级 4、Task2 优先级 5、Task3 优先级 6。"
        "当 Task3 正在执行 I2C 阻塞调用时，如果 SysTick 唤醒 Task1，内核会在中断退出时触发 PendSV，"
        "Task1 立即抢占 Task3；Task3 的 I2C 传输会在 Task1 再次阻塞后继续。由于 HAL I2C 是阻塞式，"
        "Task3 在传输期间不会主动让出 CPU，但传输时间只有约 1 ms，对 LED 的微秒级边沿没有可见影响。"
    )
    body(
        "系统的实时性瓶颈不在任务调度，而在 I2C 的 80 ms 转换等待和 HAL 阻塞传输。如果以后要进一步提高实时性，"
        "可以把 AHT20 读取改成“状态机 + 定时器/事件标志”的非阻塞方式：Task3 发送命令后挂起，80 ms 后由定时器唤醒，"
        "或者用 I2C 中断/DMA + 信号量通知。当前 2 s 周期下没有必要这样做。"
    )
    body(
        "周期抖动方面，SysTick 为 1 kHz，OSTimeDlyHMSM 的量化误差为 1 ms；中断延迟取决于当前临界区长度和中断优先级。"
        "本工程临界区都很短，I2C 传输使用 HAL 阻塞但不在临界区内，因此 LED 周期的抖动应在毫秒级以内。"
        "如果用示波器测量，建议用“无限余辉”或“周期测量”功能，连续观察 1 分钟，记录最大值和最小值。"
    )


def section6():
    h1("6  结论")
    body(
        "本实验完成了 uC/OS-III 在 STM32F103C8T6 上的移植，并构建了三个周期任务：1 s 的 LED1、3 s 的 LED2、"
        "2 s 的 AHT20 采集与串口输出。移植的关键是正确接管 PendSV 和 SysTick、配置好任务栈和优先级、"
        "在 OSStart() 之后初始化系统节拍，并让所有任务通过 OSTimeDlyHMSM 的 PERIODIC 选项实现无累积误差的周期。"
    )
    body(
        "在 I2C 部分，使用 STM32F1 硬件 I2C1（PB6/PB7，100 kHz）读取 AHT20。AHT20 的 7 位地址为 0x38，"
        "写为 0x70、读为 0x71；初始化阶段在 status.bit3=0 时发送 0xBE 0x08 0x00，测量阶段发送 0xAC 0x33 0x00，"
        "等待 80 ms 后读 7 字节，按 20 位格式换算并用 CRC8 校验。示波器/逻辑分析仪应能看到 START、地址、ACK、"
        "命令/数据和 STOP，帧顺序与图 4-3、表 4-6 一致。"
    )
    body(
        "通过本实验，掌握了 RTOS 移植的“启动文件—节拍—上下文切换—任务创建”主线，也理解了软件 I2C 与硬件 I2C 的取舍、"
        "AHT20 命令和时序、以及 RTOS 下阻塞延时对任务调度的影响。工程已编译通过并生成可烧录 HEX，"
        "可作为后续 OLED、U8G2、网络或更多传感器实验的基础。"
    )
    body(
        "后续可改进的方向包括：用互斥量保护共享 I2C 总线；用事件标志/定时器实现非阻塞传感器采样；"
        "用 DMA + 空闲中断接收串口命令；增加看门狗和错误统计；用 OSTaskStkChk() 和 CPU 使用率统计优化栈和优先级。"
    )


def references():
    h1("参考文献")
    refs = [
        "[1] 野火. STM32F103 开发板配套教材：I2C——读写 EEPROM（第 23 章）.",
        "[2] Micrium. uC/OS-III Real-Time Kernel Documentation, V3.01.2.",
        "[3] 奥松电子. AHT20 温湿度传感器产品手册（AHT20 Product Manual）.",
        "[4] STMicroelectronics. RM0008 Reference Manual: STM32F101xx/102xx/103xx/105xx/107xx.",
        "[5] STMicroelectronics. STM32F1xx HAL Driver Documentation.",
        "[6] CSDN. STM32F103C8T6 移植 uC/OS-III 基于 HAL 库超完整详细过程. https://blog.csdn.net/weixin_43116606/article/details/105532222",
        "[7] CSDN. uC/OS-III 移植与任务创建. https://blog.csdn.net/junseven164/article/details/121534916",
        "[8] CSDN. uC/OS-III 移植踩坑与总结. https://blog.csdn.net/qq_45659777/article/details/121570886",
        "[9] CSDN. STM32 通过 I2C 接口实现温湿度（AHT20）采集. https://blog.csdn.net/qq_43279579/article/details/111597278",
        "[10] CSDN. I2C 总线通信协议及 AHT20 采集. https://blog.csdn.net/qq_46467126/article/details/121436790",
        "[11] CSDN. STM32F103 基于 I2C 协议的 AHT20 温湿度采集（HAL 库）. https://blog.csdn.net/qq_47281915/article/details/121438731",
    ]
    for ref in refs:
        p = doc.add_paragraph()
        p.paragraph_format.left_indent = Cm(0.0)
        p.paragraph_format.first_line_indent = Cm(-0.0)
        p.paragraph_format.line_spacing = 1.25
        p.paragraph_format.space_after = Pt(3)
        add_runs(p, ref, 9.5)

def appendices():
    h1("附录 A  工程结构与编译信息")
    body(
        "完整 Keil 工程位于 `RTOS_AHT20/MDK-ARM/RTOS_AHT20.uvprojx`，可直接打开编译。"
        "HEX 文件位于 `RTOS_AHT20/flash/RTOS_AHT20.hex`，BIN 文件位于同目录。"
    )
    code_block(
        r"""
RTOS_AHT20/
├─ Core/
│  ├─ Inc/  main.h board.h app.h aht20.h bsp_i2c.h bsp_uart.h stm32f1xx_hal_conf.h
│  └─ Src/  main.c app.c aht20.c bsp_i2c.c bsp_uart.c
│           stm32f1xx_it.c stm32f1xx_hal_msp.c system_stm32f1xx.c
├─ Drivers/
│  ├─ CMSIS/
│  └─ STM32F1xx_HAL_Driver/
├─ uCOS_III/
│  ├─ uCOS_CONFIG/   os_cfg.h os_cfg_app.h cpu_cfg.h lib_cfg.h app_cfg.h includes.h
│  ├─ uCOS_CPU/      cpu_core.c cpu_a.asm cpu_c.c cpu.h ...
│  ├─ uCOS_III/Ports/ARM-Cortex-M3/Generic/RealView/
│  │                 os_cpu.h os_cpu_a.s os_cpu_c.c
│  ├─ uCOS_III/Source/ os_core.c os_task.c os_time.c os_tick.c ...
│  └─ uCOS_LIB/      lib_ascii.c lib_math.c lib_mem.c lib_str.c
├─ MDK-ARM/
│  ├─ RTOS_AHT20.uvprojx
│  ├─ startup_stm32f103xb.s
│  ├─ Objects/RTOS_AHT20.hex
│  └─ Listings/RTOS_AHT20.map
├─ flash/
│  ├─ RTOS_AHT20.hex
│  ├─ RTOS_AHT20.bin
│  └─ RTOS_AHT20.map
└─ report_assets/   报告插图
""",
        cap="代码 A-1  工程目录",
    )
    table(
        ["编译项", "结果"],
        [
            ["Device", "STM32F103C8"],
            ["Compiler", "ARM Compiler 5.06（AC5）"],
            ["C 标准", "C99"],
            ["Optimization", "-O1（Keil Level 1）"],
            ["Code / RO / RW / ZI", "14088 / 384 / 76 / 8028 B"],
            ["Flash / RAM", "14548 B / 8104 B"],
            ["结果", "0 Error(s), 0 Warning(s)"],
            ["HEX", "flash/RTOS_AHT20.hex"],
        ],
        widths=[5.0, 10.4],
        cap="表 A-1  编译信息",
    )


def appendix_b():
    h1("附录 B  关键源码")
    body(
        "正文已经给出了启动文件、SysTick、main()、任务创建、LED 任务、AHT20 初始化/读取和 Task3 的核心代码。"
        "这里补充 I2C 总线恢复和 CRC8 两段容易出错、又比较关键的实现，完整文件见工程源码。"
    )
    code_block(
        r"""
/* bsp_i2c.c：总线被从机拉死时的恢复流程 */
void bsp_i2c_recover(void)
{
    (void)HAL_I2C_DeInit(&hi2c1);

    /* PB6/PB7 当普通开漏 GPIO */
    GPIO_InitTypeDef gpio = {0};
    __HAL_RCC_GPIOB_CLK_ENABLE();
    gpio.Pin = GPIO_PIN_6 | GPIO_PIN_7;
    gpio.Mode = GPIO_MODE_OUTPUT_OD;
    gpio.Speed = GPIO_SPEED_FREQ_HIGH;
    HAL_GPIO_Init(GPIOB, &gpio);

    HAL_GPIO_WritePin(GPIOB, GPIO_PIN_6 | GPIO_PIN_7, GPIO_PIN_SET);
    HAL_Delay(1);

    if (HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_7) == GPIO_PIN_RESET) {
        for (uint8_t i = 0; i < 9U; ++i) {
            HAL_GPIO_WritePin(GPIOB, GPIO_PIN_6, GPIO_PIN_RESET);
            HAL_Delay(1);
            HAL_GPIO_WritePin(GPIOB, GPIO_PIN_6, GPIO_PIN_SET);
            HAL_Delay(1);
        }
        /* 手动 STOP：SCL 高时 SDA 由低变高 */
        HAL_GPIO_WritePin(GPIOB, GPIO_PIN_7, GPIO_PIN_RESET);
        HAL_Delay(1);
        HAL_GPIO_WritePin(GPIOB, GPIO_PIN_6, GPIO_PIN_SET);
        HAL_Delay(1);
        HAL_GPIO_WritePin(GPIOB, GPIO_PIN_7, GPIO_PIN_SET);
        HAL_Delay(1);
    }

    i2c_hw_init();
}
""",
        cap="代码 B-1  I2C 总线恢复",
    )
    code_block(
        r"""
/* aht20.c：CRC8，多项式 0x31，初值 0xFF */
static uint8_t crc8(const uint8_t *data, uint8_t len)
{
    uint8_t crc = 0xFFU;

    for (uint8_t i = 0; i < len; ++i) {
        crc ^= data[i];
        for (uint8_t bit = 0; bit < 8U; ++bit) {
            if ((crc & 0x80U) != 0U) {
                crc = (uint8_t)((crc << 1) ^ 0x31U);
            } else {
                crc = (uint8_t)(crc << 1);
            }
        }
    }
    return crc;
}
""",
        cap="代码 B-2  AHT20 CRC8",
    )
    body(
        "调试建议：先在不加 RTOS 的裸机工程里确认 AHT20 能读、串口能出数，再把 aht20.c/bsp_i2c.c 原样加入 RTOS 工程；"
        "这样可以把“传感器/接线问题”和“RTOS 移植问题”分开，避免同时改两处导致无法定位。"
    )


def appendix_c():
    h1("附录 C  实测记录表")
    body(
        "下表用于烧录后记录实物数据。建议至少记录 3 组 LED 周期、3 组串口温湿度和 1 组完整 I2C 解码结果；"
        "如果有示波器截图，可把图片插入本页或第 4.8 节。"
    )
    table(
        ["记录项", "第 1 次", "第 2 次", "第 3 次", "备注"],
        [
            ["LED1 周期 / s", "", "", "", "设计 1.000 s"],
            ["LED1 占空比 / %", "", "", "", "设计 50%"],
            ["LED2 周期 / s", "", "", "", "设计 3.000 s"],
            ["LED2 占空比 / %", "", "", "", "设计 50%"],
            ["Task3 间隔 / s", "", "", "", "设计 2.000 s"],
            ["温度 / ℃", "", "", "", "串口读数"],
            ["湿度 / %RH", "", "", "", "串口读数"],
            ["CRC", "", "", "", "OK / ERR"],
            ["SCL 频率 / kHz", "", "", "", "设计 100 kHz"],
            ["地址（7 位）", "", "", "", "应为 0x38"],
            ["初始化命令", "", "", "", "0xBE 0x08 0x00"],
            ["测量命令", "", "", "", "0xAC 0x33 0x00"],
        ],
        widths=[4.6, 2.8, 2.8, 2.8, 3.4],
        cap="表 C-1  实测数据记录",
    )
    table(
        ["检查项", "结果", "说明"],
        [
            ["上电 LED1 是否 1 s 闪烁", "□ 是  □ 否", ""],
            ["上电 LED2 是否 3 s 闪烁", "□ 是  □ 否", ""],
            ["串口是否每 2 s 输出", "□ 是  □ 否", ""],
            ["AHT20 init 是否 OK", "□ 是  □ 否", ""],
            ["CRC 是否 OK", "□ 是  □ 否", ""],
            ["I2C 解码地址是否 0x38", "□ 是  □ 否", ""],
            ["是否看到 START/STOP", "□ 是  □ 否", ""],
            ["中文是否正常", "□ 是  □ 否", "串口助手 UTF-8"],
        ],
        widths=[6.6, 4.4, 6.0],
        cap="表 C-2  功能检查清单",
    )
    body(
        "如果某项为“否”，按第 3.5 节和第 4.9 节的问题表逐项排查；先在裸机工程确认硬件，再回到 RTOS 工程检查节拍和任务栈。",
        indent=True,
    )


def build():
    global doc
    doc = Document()
    page_setup()
    cover()
    toc()
    abstract()
    section1()
    section2()
    section3()
    section4()
    section5()
    section6()
    references()
    appendices()
    appendix_b()
    appendix_c()
    doc.save(OUT_DOCX)
    print("saved", OUT_DOCX)


if __name__ == "__main__":
    build()
