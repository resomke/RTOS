# -*- coding: utf-8 -*-
"""Generate diagrams for the RTOS/AHT20 lab report."""
import os
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch, Rectangle
from matplotlib.lines import Line2D

BASE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(BASE, "report_assets")
os.makedirs(OUT, exist_ok=True)

plt.rcParams["font.sans-serif"] = ["Microsoft YaHei", "SimHei"]
plt.rcParams["axes.unicode_minus"] = False
plt.rcParams["figure.dpi"] = 160

C_BLUE = "#2F5597"
C_LBLUE = "#DCE6F1"
C_GREEN = "#548235"
C_LGREEN = "#E2EFDA"
C_ORANGE = "#C55A11"
C_LORANGE = "#FBE5D6"
C_GRAY = "#595959"
C_LGRAY = "#F2F2F2"


def box(ax, x, y, w, h, text, fc, ec, fs=10, bold=False, rounding=0.02):
    p = FancyBboxPatch((x, y), w, h, boxstyle=f"round,pad=0.006,rounding_size={rounding}",
                       linewidth=1.1, edgecolor=ec, facecolor=fc, zorder=2)
    ax.add_patch(p)
    ax.text(x + w / 2, y + h / 2, text, ha="center", va="center",
            fontsize=fs, color="#222222", fontweight="bold" if bold else "normal",
            zorder=3, linespacing=1.35)


def arrow(ax, x1, y1, x2, y2, color=C_GRAY, style="-|>", lw=1.2, ls="-"):
    ax.add_patch(FancyArrowPatch((x1, y1), (x2, y2), arrowstyle=style,
                                 mutation_scale=12, linewidth=lw, color=color,
                                 linestyle=ls, zorder=1))


# ---------------------------------------------------------------- architecture
def fig_arch():
    fig, ax = plt.subplots(figsize=(8.6, 5.4))
    ax.set_xlim(0, 10)
    ax.set_ylim(0, 6.4)
    ax.axis("off")

    box(ax, 0.5, 5.05, 9.0, 0.85,
        "应用层  App\nTask1：LED1 1 s    Task2：LED2 3 s    Task3：AHT20 + USART1 2 s",
        C_LBLUE, C_BLUE, fs=10.5, bold=True)
    box(ax, 0.5, 3.95, 9.0, 0.75,
        "uC/OS-III 内核（V3.01.2）\n任务管理  TCB  就绪表  调度器  时间管理  信号量/队列  中断管理",
        "#FFFFFF", C_BLUE, fs=9.8)
    box(ax, 0.5, 2.85, 4.3, 0.75,
        "Cortex-M3 移植层\nos_cpu.h / os_cpu_a.s / os_cpu_c.c", C_LGREEN, C_GREEN, fs=9.2)
    box(ax, 5.2, 2.85, 4.3, 0.75,
        "CPU 与 LIB 层\ncpu_core.c / cpu_a.asm / lib_*.c", C_LGREEN, C_GREEN, fs=9.2)
    box(ax, 0.5, 1.75, 4.3, 0.75,
        "STM32 HAL 与 BSP\nHAL_Init / RCC / GPIO / I2C / UART", C_LORANGE, C_ORANGE, fs=9.2)
    box(ax, 5.2, 1.75, 4.3, 0.75,
        "板级外设\nPC13 LED / PB12 LED / AHT20 / USB-TTL", C_LORANGE, C_ORANGE, fs=9.2)
    box(ax, 0.5, 0.55, 9.0, 0.75,
        "STM32F103C8T6：Cortex-M3 @ 72 MHz，64 KB Flash，20 KB SRAM，SysTick 1 ms",
        C_LGRAY, C_GRAY, fs=9.8, bold=True)

    for y1, y2 in [(5.05, 4.70), (3.95, 3.60), (2.85, 2.50), (1.75, 1.30)]:
        arrow(ax, 5.0, y1, 5.0, y2)
    ax.text(5.15, 4.87, "API 调用", fontsize=8, color=C_GRAY, va="center")
    ax.text(5.15, 3.77, "PendSV / SysTick", fontsize=8, color=C_GRAY, va="center")
    ax.text(5.15, 2.67, "寄存器 / 外设", fontsize=8, color=C_GRAY, va="center")

    ax.text(0.5, 6.15, "uC/OS-III 移植后的软件分层", fontsize=13, fontweight="bold", color=C_BLUE)
    fig.tight_layout()
    fig.savefig(os.path.join(OUT, "fig_arch.png"), bbox_inches="tight", facecolor="white")
    plt.close(fig)


# -------------------------------------------------------------------- timeline
def fig_tasks():
    fig, ax = plt.subplots(figsize=(10.2, 4.4))
    ax.set_xlim(-0.2, 12.2)
    ax.set_ylim(-0.2, 4.2)
    ax.set_yticks([3, 2, 1])
    ax.set_yticklabels(["Task1  LED1 (1 s)", "Task2  LED2 (3 s)", "Task3  AHT20/串口 (2 s)"], fontsize=9.5)
    ax.set_xlabel("时间 / s", fontsize=10)
    ax.set_xticks(range(0, 13))
    ax.grid(axis="x", color="#D9D9D9", linestyle="--", linewidth=0.7, zorder=0)
    ax.set_axisbelow(True)

    # LED1: 0.5 on / 0.5 off
    for k in range(12):
        t = k
        ax.add_patch(Rectangle((t, 2.68), 0.5, 0.64, facecolor=C_BLUE, edgecolor="white", linewidth=0.8, alpha=0.9, zorder=2))
        ax.add_patch(Rectangle((t + 0.5, 2.68), 0.5, 0.64, facecolor="#FFFFFF", edgecolor=C_BLUE, linewidth=0.8, zorder=2))
    # LED2: 1.5 on / 1.5 off
    for k in range(4):
        t = 3 * k
        ax.add_patch(Rectangle((t, 1.68), 1.5, 0.64, facecolor=C_GREEN, edgecolor="white", linewidth=0.8, alpha=0.9, zorder=2))
        ax.add_patch(Rectangle((t + 1.5, 1.68), 1.5, 0.64, facecolor="#FFFFFF", edgecolor=C_GREEN, linewidth=0.8, zorder=2))
    # Task3 bursts at 0,2,4,... width 0.12
    for k in range(6):
        t = 2 * k
        ax.add_patch(Rectangle((t, 0.68), 0.13, 0.64, facecolor=C_ORANGE, edgecolor="none", zorder=3))
        ax.text(t + 0.17, 1.0, "采集+发送", fontsize=7.2, color=C_ORANGE, va="center")
    # annotations
    ax.annotate("亮 0.5 s", xy=(0.25, 3.32), xytext=(0.25, 3.75), ha="center", fontsize=8,
                arrowprops=dict(arrowstyle="-", color=C_BLUE, lw=0.8), color=C_BLUE)
    ax.annotate("灭 0.5 s", xy=(0.75, 3.32), xytext=(1.45, 3.75), ha="center", fontsize=8,
                arrowprops=dict(arrowstyle="-", color=C_BLUE, lw=0.8), color=C_BLUE)
    ax.annotate("亮 1.5 s", xy=(0.75, 2.32), xytext=(0.75, 2.15), ha="center", fontsize=8,
                arrowprops=dict(arrowstyle="-", color="white", lw=0.8), color="white")
    ax.annotate("灭 1.5 s", xy=(2.25, 2.32), xytext=(2.55, 1.98), ha="center", fontsize=8,
                arrowprops=dict(arrowstyle="-", color=C_GREEN, lw=0.8), color=C_GREEN)
    ax.text(11.55, 0.28, "橙色窄条为串口突发（约 0.1 s，图中放大显示）", fontsize=7.5, color=C_GRAY, ha="right")
    ax.set_title("三个任务的周期与相位关系（上电后从 t=0 开始）", fontsize=12, fontweight="bold", color=C_BLUE, pad=8)
    ax.spines[["top", "right"]].set_visible(False)
    fig.tight_layout()
    fig.savefig(os.path.join(OUT, "fig_tasks.png"), bbox_inches="tight", facecolor="white")
    plt.close(fig)


# ------------------------------------------------------------------ I2C waves
def i2c_frame(ax, bytes_vals, addr, title, read=False, t0=0.0):
    """Draw one I2C transaction: START, address+ACK, data bytes+ACK, STOP."""
    bit = 10.0  # us at 100 kHz
    # bits: address 8 + ack 1, each data 8 + ack 1
    bits = []
    labels = []
    # address bits MSB first
    for i in range(7, -1, -1):
        bits.append((addr >> i) & 1)
    labels += ["A6", "A5", "A4", "A3", "A2", "A1", "A0", "R/W"]
    bits.append(0)  # ACK from slave
    labels.append("ACK")
    for bi, b in enumerate(bytes_vals):
        for i in range(7, -1, -1):
            bits.append((b >> i) & 1)
        labels += [f"D{bi}.{i}" for i in range(7, -1, -1)]
        bits.append(0 if bi < len(bytes_vals) - 1 else 1)  # ACK except last NACK
        labels.append("ACK" if bi < len(bytes_vals) - 1 else "NACK")

    n = len(bits)
    # Build SCL and SDA piecewise at 0.1 us resolution
    dt = 0.1
    total = (n + 1) * bit + 20
    t = np.arange(0, total, dt)
    scl = np.zeros_like(t)
    sda = np.zeros_like(t)
    # idle high before start
    scl[:] = 1
    sda[:] = 1
    # START: SDA falls while SCL high at t=5 us, then SCL falls at 7.5 us
    start_t = 5.0
    sda[t < start_t] = 1
    sda[(t >= start_t)] = 0
    scl[(t >= start_t + 2.5)] = 0
    # each bit cell: SCL low 5us, high 5us; data set at cell start
    base = start_t + 2.5
    for k, b in enumerate(bits):
        cell = base + k * bit
        # data valid from cell start (SCL low) through high
        sda[(t >= cell)] = b
        scl[(t >= cell)] = 0
        scl[(t >= cell + 5.0)] = 1
    end_data = base + n * bit
    # STOP: SCL low, SDA low, then SCL high, SDA rises
    scl[(t >= end_data)] = 0
    sda[(t >= end_data)] = 0
    scl[(t >= end_data + 2.5)] = 1
    sda[(t >= end_data + 5.0)] = 1
    scl[(t >= end_data + 7.5)] = 1

    # plot with step
    ax.step(t, scl + 1.35, where="post", color=C_BLUE, linewidth=1.4, label="SCL (PB6)")
    ax.step(t, sda + 0.0, where="post", color=C_ORANGE, linewidth=1.4, label="SDA (PB7)")
    ax.set_yticks([0, 0.8, 1.35, 2.15])
    ax.set_yticklabels(["0", "1", "0", "1"], fontsize=8)
    ax.set_ylim(-0.35, 2.55)
    ax.set_xlim(0, total)
    ax.set_title(title, fontsize=9.8, color=C_BLUE, fontweight="bold", loc="left")
    ax.grid(axis="x", color="#E7E6E6", linestyle=":", linewidth=0.6)
    ax.spines[["top", "right"]].set_visible(False)
    ax.set_ylabel("逻辑电平", fontsize=8)
    # labels
    ax.text(start_t, 2.38, "START", fontsize=7, color=C_ORANGE, ha="center")
    # address label
    ax.text(start_t + 2.5 + 4 * bit, 2.38, f"地址 0x{addr:02X}", fontsize=7.2, color=C_GRAY, ha="center")
    # byte labels above groups
    for bi, b in enumerate(bytes_vals):
        c = start_t + 2.5 + (9 + 9 * bi) * bit + 4.5 * bit
        ax.text(c, 2.38, f"0x{b:02X}", fontsize=6.8, color=C_GRAY, ha="center")
    ax.text(end_data + 2.5, 2.38, "STOP", fontsize=7, color=C_ORANGE, ha="center")
    # bit timing bracket for one bit
    k = 2
    cell = start_t + 2.5 + k * bit
    ax.annotate("", xy=(cell, -0.18), xytext=(cell + bit, -0.18),
                arrowprops=dict(arrowstyle="<->", color=C_GRAY, lw=0.8))
    ax.text(cell + bit / 2, -0.33, "10 µs", fontsize=7, color=C_GRAY, ha="center")
    return total


def fig_i2c():
    fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(11.2, 6.2), gridspec_kw={"height_ratios": [1, 1]})
    t1 = i2c_frame(ax1, [0xBE, 0x08, 0x00], 0x70, "初始化写命令帧：START + 0x70 + 0xBE 0x08 0x00 + STOP")
    ax1.set_xlabel("时间 / µs", fontsize=8)
    # read frame: 7 bytes
    t2 = i2c_frame(ax2, [0x18, 0x80, 0x00, 0x06, 0x00, 0x00, 0x23], 0x71,
                   "测量读数据帧：START + 0x71 + 7 字节（末字节 NACK）+ STOP")
    ax2.set_xlabel("时间 / µs", fontsize=8)
    fig.suptitle("AHT20 I2C 总线时序（按 100 kHz 标准模式重绘，非实物示波器截图）",
                 fontsize=12, fontweight="bold", color=C_BLUE, y=0.99)
    handles, labels = ax1.get_legend_handles_labels()
    fig.legend(handles, labels, loc="lower center", ncol=2, frameon=False, fontsize=8)
    fig.tight_layout(rect=[0, 0.035, 1, 0.95])
    fig.savefig(os.path.join(OUT, "fig_i2c_wave.png"), bbox_inches="tight", facecolor="white")
    plt.close(fig)


# ------------------------------------------------------------------ AHT20 flow
def fig_aht20_flow():
    fig, ax = plt.subplots(figsize=(9.2, 6.8))
    ax.set_xlim(0, 10.9)
    ax.set_ylim(0, 9.2)
    ax.axis("off")

    def step(y, text, fc=C_LBLUE, ec=C_BLUE, x=0.5, w=4.0, h=0.62):
        box(ax, x, y, w, h, text, fc, ec, fs=8.6)
        return y

    def down(y1, y2, x=2.5):
        arrow(ax, x, y1, x, y2)

    ax.text(2.5, 8.75, "上电初始化（只执行一次）", ha="center", fontsize=11, fontweight="bold", color=C_BLUE)
    step(7.85, "上电 / 复位，等待 ≥ 40 ms")
    down(7.85, 7.55)
    step(6.95, "读状态字节（地址 0x71，1 字节）")
    down(6.95, 6.65)
    step(6.05, "status.bit3 = 1 ?（已校准）")
    # no branch
    arrow(ax, 2.5, 6.05, 2.5, 5.75, color=C_ORANGE)
    ax.text(2.65, 5.88, "否", fontsize=8, color=C_ORANGE)
    step(5.15, "发送 0xBE 0x08 0x00\n（初始化 / 校准命令）", C_LORANGE, C_ORANGE)
    down(5.15, 4.85)
    step(4.25, "等待 10 ms")
    down(4.25, 3.95)
    # yes branch: go right and down to merge point
    ax.plot([4.5, 5.15], [6.36, 6.36], color=C_GREEN, lw=1.2)
    ax.plot([5.15, 5.15], [6.36, 3.72], color=C_GREEN, lw=1.2, ls="--")
    arrow(ax, 5.15, 3.72, 4.55, 3.72, color=C_GREEN)
    ax.text(5.22, 5.0, "是：跳过校准", fontsize=7.8, color=C_GREEN, rotation=90, va="center")
    # merge / finish
    ax.plot([2.5, 4.5], [3.72, 3.72], color=C_GREEN, lw=1.2)
    ax.plot([2.5, 2.5], [3.95, 3.72], color=C_GREEN, lw=1.2)
    ax.text(2.55, 3.45, "初始化完成，进入右侧 2 s 测量循环", fontsize=8.2, color=C_GREEN)

    # Right column: measurement loop
    ax.text(7.65, 8.75, "每 2 s 测量循环", ha="center", fontsize=11, fontweight="bold", color=C_ORANGE)
    step(7.85, "发送 0xAC 0x33 0x00（触发测量）", C_LORANGE, C_ORANGE, x=5.7, w=3.9)
    down(7.85, 7.55, x=7.65)
    step(6.95, "等待 80 ms（转换时间）", C_LORANGE, C_ORANGE, x=5.7, w=3.9)
    down(6.95, 6.65, x=7.65)
    step(6.05, "读 7 字节（地址 0x71）\nstatus + hum20 + temp20 + CRC", C_LORANGE, C_ORANGE, x=5.7, w=3.9)
    down(6.05, 5.75, x=7.65)
    step(5.15, "status.bit7 = 0 ?（转换完成）", C_LORANGE, C_ORANGE, x=5.7, w=3.9)
    down(5.15, 4.85, x=7.65)
    step(4.25, "CRC8 校验；换算 T / RH；串口输出", C_LGREEN, C_GREEN, x=5.7, w=3.9)
    down(4.25, 3.95, x=7.65)
    step(3.35, "OSTimeDlyHMSM(0,0,2,0, PERIODIC)\n等待下一个 2 s 周期", C_LGREEN, C_GREEN, x=5.7, w=3.9)

    # busy retry loop: right side
    ax.plot([9.6, 9.78], [5.46, 5.46], color=C_ORANGE, lw=1.0, ls="--")
    ax.plot([9.78, 9.78], [5.46, 6.36], color=C_ORANGE, lw=1.0, ls="--")
    arrow(ax, 9.78, 6.36, 9.62, 6.36, color=C_ORANGE)
    ax.text(9.84, 5.9, "忙，重读", fontsize=7.4, color=C_ORANGE, rotation=90, va="center")

    # main loop: far right
    ax.add_patch(FancyArrowPatch((10.35, 3.66), (10.35, 8.16), arrowstyle="-|>",
                                 mutation_scale=12, linewidth=1.0, color=C_GREEN,
                                 connectionstyle="arc3,rad=0.0", linestyle="--"))
    ax.text(10.47, 5.9, "循环", fontsize=8, color=C_GREEN, rotation=90, va="center")

    ax.text(5.2, 0.45, "说明：初始化只在 Task3 启动时执行一次；测量循环每 2 s 执行一次。",
            ha="center", fontsize=8.2, color=C_GRAY)
    fig.tight_layout()
    fig.savefig(os.path.join(OUT, "fig_aht20_flow.png"), bbox_inches="tight", facecolor="white")
    plt.close(fig)


def fig_wiring():
    fig, ax = plt.subplots(figsize=(9.8, 6.0))
    ax.set_xlim(0, 11.5)
    ax.set_ylim(0, 7)
    ax.axis("off")

    box(ax, 0.5, 1.95, 4.0, 3.65,
        "STM32F103C8T6\n最小系统板\n\n3.3 V / GND\nPC13 → LED1\nPB12 → LED2\nPB6  → I2C1_SCL\nPB7  → I2C1_SDA\nPA9  → USART1_TX\nPA10 → USART1_RX",
        C_LBLUE, C_BLUE, fs=9.0)
    box(ax, 5.5, 5.0, 3.6, 1.05, "AHT20 温湿度模块\nVCC / GND / SCL / SDA\n7 位地址 0x38", C_LGREEN, C_GREEN, fs=8.8)
    box(ax, 5.5, 3.2, 3.6, 0.95, "USB-TTL（CH340）\nRX / TX / GND\n115200-8-N-1", C_LORANGE, C_ORANGE, fs=8.8)
    box(ax, 5.5, 1.0, 3.6, 1.2, "LED1：PC13 板载，低电平亮\nLED2：PB12 + 330 Ω 到 GND\n高电平亮", "#FFFFFF", C_GRAY, fs=8.4)

    # I2C
    ax.plot([4.5, 5.5], [4.55, 4.55], color=C_GREEN, lw=1.4)
    ax.plot([4.5, 5.5], [4.35, 4.35], color=C_GREEN, lw=1.4)
    ax.text(4.98, 4.68, "SCL", fontsize=7.5, color=C_GREEN, ha="center")
    ax.text(4.98, 4.18, "SDA", fontsize=7.5, color=C_GREEN, ha="center")
    # UART
    ax.plot([4.5, 5.5], [3.75, 3.75], color=C_ORANGE, lw=1.4)
    ax.plot([4.5, 5.5], [3.55, 3.55], color=C_ORANGE, lw=1.4)
    ax.text(4.98, 3.88, "TX→RX", fontsize=7.0, color=C_ORANGE, ha="center")
    ax.text(4.98, 3.40, "RX←TX", fontsize=7.0, color=C_ORANGE, ha="center")
    # LED lines, routed below USB-TTL
    ax.plot([4.5, 5.0], [2.45, 2.45], color=C_BLUE, lw=1.2)
    ax.plot([5.0, 5.0], [2.45, 1.75], color=C_BLUE, lw=1.2)
    ax.plot([5.0, 5.5], [1.75, 1.75], color=C_BLUE, lw=1.2)
    ax.text(5.12, 2.15, "PC13", fontsize=7.2, color=C_BLUE, rotation=90, va="center")
    ax.plot([4.5, 4.8], [2.25, 2.25], color=C_GREEN, lw=1.2)
    ax.plot([4.8, 4.8], [2.25, 1.40], color=C_GREEN, lw=1.2)
    ax.plot([4.8, 5.5], [1.40, 1.40], color=C_GREEN, lw=1.2)
    ax.text(4.72, 1.80, "PB12", fontsize=7.2, color=C_GREEN, rotation=90, va="center")

    ax.text(0.5, 6.45, "硬件连接图（AHT20 与 LED 共用 3.3 V 和 GND）",
            fontsize=12, fontweight="bold", color=C_BLUE)
    ax.text(0.5, 0.35, "注意：AHT20 模块的 SCL/SDA 需要上拉（模块一般自带 4.7 kΩ）；"
                       "AHT20 芯片供电范围 2.0–5.5 V，但最小系统板建议统一用 3.3 V。",
            fontsize=8.0, color=C_GRAY)
    fig.tight_layout()
    fig.savefig(os.path.join(OUT, "fig_wiring.png"), bbox_inches="tight", facecolor="white")
    plt.close(fig)


def fig_serial():
    lines = [
        "BOOT: STM32F103C8T6 / uC/OS-III / AHT20",
        "I2C1: PB6=SCL, PB7=SDA, 100 kHz; AHT20 addr=0x38",
        "============================================",
        "  uC/OS-III + STM32F103C8T6 + AHT20",
        "  SYSCLK = 72000000 Hz, OS tick = 1000 Hz",
        "  Task1: PC13 LED 1 s, Task2: PB12 LED 3 s",
        "  Task3: AHT20 2 s, USART1 115200-8-N-1",
        "============================================",
        "[TASK3] AHT20 init (7-bit address 0x38)...",
        "[TASK3] AHT20 init OK",
        "hello uc/OS! 欢迎来到RTOS多任务环境！",
        "[TASK3] AHT20: T=25.0 C, RH=50.0 %, CRC=OK",
        "hello uc/OS! 欢迎来到RTOS多任务环境！",
        "[TASK3] AHT20: T=25.1 C, RH=50.2 %, CRC=OK",
        "hello uc/OS! 欢迎来到RTOS多任务环境！",
        "[TASK3] AHT20: T=25.1 C, RH=50.3 %, CRC=OK",
    ]
    fig, ax = plt.subplots(figsize=(10.4, 5.6))
    ax.axis("off")
    ax.add_patch(Rectangle((0.02, 0.07), 0.96, 0.89, transform=ax.transAxes,
                           facecolor="#101418", edgecolor="#444444", linewidth=1.0))
    ax.add_patch(Rectangle((0.02, 0.89), 0.96, 0.07, transform=ax.transAxes,
                           facecolor="#2B3138", edgecolor="#444444", linewidth=1.0))
    ax.text(0.04, 0.925, "串口助手  COM3  115200-8-N-1  UTF-8", transform=ax.transAxes,
            fontsize=8.2, color="#D9D9D9", family="Microsoft YaHei")
    y = 0.855
    for line in lines:
        if line.startswith("hello"):
            color = "#7EE787"
        elif line.startswith("[TASK3]"):
            color = "#79C0FF"
        else:
            color = "#D9D9D9"
        ax.text(0.04, y, line, transform=ax.transAxes, fontsize=8.2, color=color,
                family="Microsoft YaHei", va="top")
        y -= 0.050
    fig.text(0.5, 0.015, "注：以上为程序格式化输出示例；实物截图请用你自己的串口助手替换。",
             ha="center", fontsize=7.4, color=C_GRAY)
    fig.tight_layout(rect=[0, 0.03, 1, 1])
    fig.savefig(os.path.join(OUT, "fig_serial.png"), bbox_inches="tight", facecolor="white")
    plt.close(fig)


if __name__ == "__main__":
    fig_arch()
    fig_tasks()
    fig_i2c()
    fig_aht20_flow()
    fig_wiring()
    fig_serial()
    print("figures written to", OUT)
