/**
  ******************************************************************************
  * @file    app.c
  * @brief   任务一：uC/OS-III 三个任务
  *
  *   Task1：PC13 板载 LED，1 s 周期（亮 0.5 s / 灭 0.5 s）
  *   Task2：PB12 外接 LED，3 s 周期（亮 1.5 s / 灭 1.5 s）
  *   Task3：USART1 每 2 s 发送“hello uc/OS! 欢迎来到RTOS多任务环境！”
  *
  * 说明：本工程是任务一的纯净版本，不初始化 AHT20，也不访问 I2C；
  *       任务二（3）的 AHT20 版本见 RTOS_AHT20 工程。
  ******************************************************************************
  */
#include "main.h"
#include "app.h"
#include "board.h"
#include "bsp_uart.h"
#include <stdint.h>

/* ---------------- 任务栈（静态分配，避免使用堆） ---------------- */
static CPU_STK AppTaskStartStk[APP_TASK_START_STK_SIZE];
static CPU_STK AppTaskLed1Stk[APP_TASK_LED1_STK_SIZE];
static CPU_STK AppTaskLed2Stk[APP_TASK_LED2_STK_SIZE];
static CPU_STK AppTaskUartStk[APP_TASK_UART_STK_SIZE];

/* ---------------- 任务控制块 ---------------- */
OS_TCB AppTaskStartTCB;
OS_TCB AppTaskLed1TCB;
OS_TCB AppTaskLed2TCB;
OS_TCB AppTaskUartTCB;

static void AppTaskLed1(void *p_arg);
static void AppTaskLed2(void *p_arg);
static void AppTaskUart(void *p_arg);
static void AppTaskCreate(void);

/**
  * @brief  系统节拍初始化：HCLK / OS_CFG_TICK_RATE_HZ = 72 MHz / 1000 = 72000。
  */
static void BSP_Init(void)
{
    OS_CPU_SysTickInit(SystemCoreClock / OSCfg_TickRate_Hz);
}

void App_Init(void)
{
    OS_ERR err;

    OSInit(&err);
    if (err != OS_ERR_NONE)
    {
        Error_Handler();
    }

    OSTaskCreate(&AppTaskStartTCB,
                 "Start Task",
                 AppTaskStart,
                 (void *)0,
                 APP_TASK_START_PRIO,
                 &AppTaskStartStk[0],
                 APP_TASK_START_STK_SIZE / 10u,
                 APP_TASK_START_STK_SIZE,
                 0u,
                 0u,
                 (void *)0,
                 (OS_OPT)(OS_OPT_TASK_STK_CHK | OS_OPT_TASK_STK_CLR),
                 &err);
    if (err != OS_ERR_NONE)
    {
        Error_Handler();
    }
}

void AppTaskStart(void *p_arg)
{
    OS_ERR err;

    (void)p_arg;

    BSP_Init();
    CPU_Init();

    bsp_uart_puts("\r\n============================================\r\n");
    bsp_uart_puts("  Task1: uC/OS-III + STM32F103C8T6\r\n");
    bsp_uart_puts("  Task1: PC13 LED 1 s, Task2: PB12 LED 3 s\r\n");
    bsp_uart_puts("  Task3: USART1 greeting every 2 s\r\n");
    bsp_uart_puts("============================================\r\n");

    AppTaskCreate();

    OSTaskSuspend(&AppTaskStartTCB, &err);
}

static void AppTaskCreate(void)
{
    OS_ERR err;

    OSTaskCreate(&AppTaskLed1TCB,
                 "LED1 Task",
                 AppTaskLed1,
                 (void *)0,
                 APP_TASK_LED1_PRIO,
                 &AppTaskLed1Stk[0],
                 APP_TASK_LED1_STK_SIZE / 10u,
                 APP_TASK_LED1_STK_SIZE,
                 0u, 0u, (void *)0,
                 (OS_OPT)(OS_OPT_TASK_STK_CHK | OS_OPT_TASK_STK_CLR),
                 &err);
    if (err != OS_ERR_NONE)
    {
        Error_Handler();
    }

    OSTaskCreate(&AppTaskLed2TCB,
                 "LED2 Task",
                 AppTaskLed2,
                 (void *)0,
                 APP_TASK_LED2_PRIO,
                 &AppTaskLed2Stk[0],
                 APP_TASK_LED2_STK_SIZE / 10u,
                 APP_TASK_LED2_STK_SIZE,
                 0u, 0u, (void *)0,
                 (OS_OPT)(OS_OPT_TASK_STK_CHK | OS_OPT_TASK_STK_CLR),
                 &err);
    if (err != OS_ERR_NONE)
    {
        Error_Handler();
    }

    OSTaskCreate(&AppTaskUartTCB,
                 "UART Task",
                 AppTaskUart,
                 (void *)0,
                 APP_TASK_UART_PRIO,
                 &AppTaskUartStk[0],
                 APP_TASK_UART_STK_SIZE / 10u,
                 APP_TASK_UART_STK_SIZE,
                 0u, 0u, (void *)0,
                 (OS_OPT)(OS_OPT_TASK_STK_CHK | OS_OPT_TASK_STK_CLR),
                 &err);
    if (err != OS_ERR_NONE)
    {
        Error_Handler();
    }
}

/** Task1：PC13，1 s 周期。 */
static void AppTaskLed1(void *p_arg)
{
    OS_ERR err;
    (void)p_arg;

    LED1_OFF();

    while (DEF_TRUE)
    {
        LED1_ON();
        OSTimeDlyHMSM(0u, 0u, 0u, 500u,
                      (OS_OPT)(OS_OPT_TIME_HMSM_STRICT | OS_OPT_TIME_PERIODIC), &err);
        LED1_OFF();
        OSTimeDlyHMSM(0u, 0u, 0u, 500u,
                      (OS_OPT)(OS_OPT_TIME_HMSM_STRICT | OS_OPT_TIME_PERIODIC), &err);
    }
}

/** Task2：PB12，3 s 周期。 */
static void AppTaskLed2(void *p_arg)
{
    OS_ERR err;
    (void)p_arg;

    LED2_OFF();

    while (DEF_TRUE)
    {
        LED2_ON();
        OSTimeDlyHMSM(0u, 0u, 1u, 500u,
                      (OS_OPT)(OS_OPT_TIME_HMSM_STRICT | OS_OPT_TIME_PERIODIC), &err);
        LED2_OFF();
        OSTimeDlyHMSM(0u, 0u, 1u, 500u,
                      (OS_OPT)(OS_OPT_TIME_HMSM_STRICT | OS_OPT_TIME_PERIODIC), &err);
    }
}

/** Task3：USART1，每 2 s 发送问候语。 */
static void AppTaskUart(void *p_arg)
{
    OS_ERR err;
    (void)p_arg;

    while (DEF_TRUE)
    {
        bsp_uart_puts("hello uc/OS! 欢迎来到RTOS多任务环境！\r\n");
        OSTimeDlyHMSM(0u, 0u, 2u, 0u,
                      (OS_OPT)(OS_OPT_TIME_HMSM_STRICT | OS_OPT_TIME_PERIODIC), &err);
    }
}
