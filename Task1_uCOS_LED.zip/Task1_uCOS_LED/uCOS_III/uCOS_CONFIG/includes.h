/**
  ******************************************************************************
  * @file    includes.h
  * @brief   应用、uC/OS-III 和 STM32 HAL 的统一包含入口。
  ******************************************************************************
  */
#ifndef INCLUDES_PRESENT
#define INCLUDES_PRESENT

#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#include <cpu.h>
#include <lib_def.h>
#include <lib_ascii.h>
#include <lib_math.h>
#include <lib_mem.h>
#include <lib_str.h>

#include <os.h>

#include "stm32f1xx_hal.h"

#endif /* INCLUDES_PRESENT */
