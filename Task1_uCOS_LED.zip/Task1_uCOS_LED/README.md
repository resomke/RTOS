# 任务一：uC/OS-III 三任务（LED + 串口问候语）

这是任务一的**纯净版本**，不初始化 AHT20，不访问 I2C。

## 功能

| 任务 | 优先级 | 周期 | 动作 |
|---|---|---|---|
| Task1 | 4 | 1 s | PC13 板载 LED：亮 0.5 s / 灭 0.5 s |
| Task2 | 5 | 3 s | PB12 外接 LED：亮 1.5 s / 灭 1.5 s |
| Task3 | 6 | 2 s | USART1 发送 `hello uc/OS! 欢迎来到RTOS多任务环境！` |

## 打开与编译

1. 打开 `MDK-ARM/Task1_uCOS_LED.uvprojx`。
2. 编译器选择 **ARM Compiler 5（AC5）**。
3. F7 编译，F8 下载。

## 接线

| STM32F103C8T6 | 外设 |
|---|---|
| PC13 | 板载 LED（低电平亮） |
| PB12 | 外接 LED：PB12 → 330 Ω → LED → GND（高电平亮） |
| PA9 | USB-TTL RX（115200-8-N-1） |
| PA10 | USB-TTL TX（可不接） |
| GND | USB-TTL GND，必须共地 |

## 烧录

`flash/Task1_uCOS_LED.hex` 是编译好的固件，可直接烧录：

```powershell
STM32_Programmer_CLI.exe -c port=SWD -w flash\Task1_uCOS_LED.hex -v -rst
```

## 预期现象

- PC13 LED 以 1 s 周期均匀闪烁。
- PB12 LED 以 3 s 周期闪烁。
- 串口每 2 s 输出一行问候语，中文正常（串口助手设为 UTF-8）。

## 说明

- 本工程只覆盖任务一；任务二（2）裸机 AHT20 见 `Task2_AHT20_Bare`，任务二（3）RTOS + AHT20 见 `RTOS_AHT20`。
- uC/OS-III 源码版权归 Micrium/Straight Up 所有，仅用于课程学习。
