objects\cpu_core.o: ..\uCOS_III\uCOS_CPU\cpu_core.c
objects\cpu_core.o: ..\uCOS_III\uCOS_CPU\cpu_core.h
objects\cpu_core.o: ..\uCOS_III\uCOS_CPU\ARM-Cortex-M3\RealView\cpu.h
objects\cpu_core.o: ..\uCOS_III\uCOS_CPU\cpu_def.h
objects\cpu_core.o: ..\uCOS_III\uCOS_CONFIG\cpu_cfg.h
objects\cpu_core.o: ..\uCOS_III\uCOS_LIB\lib_def.h
