objects\cpu_a.o: ..\uCOS_III\uCOS_CPU\ARM-Cortex-M3\RealView\cpu_a.asm
