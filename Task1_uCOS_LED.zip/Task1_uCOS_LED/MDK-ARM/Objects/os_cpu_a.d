objects\os_cpu_a.o: ..\uCOS_III\uCOS_III\Ports\ARM-Cortex-M3\Generic\RealView\os_cpu_a.s
