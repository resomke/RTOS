objects\lib_math.o: ..\uCOS_III\uCOS_LIB\lib_math.c
objects\lib_math.o: ..\uCOS_III\uCOS_LIB\lib_math.h
objects\lib_math.o: ..\uCOS_III\uCOS_CPU\ARM-Cortex-M3\RealView\cpu.h
objects\lib_math.o: ..\uCOS_III\uCOS_CPU\cpu_def.h
objects\lib_math.o: ..\uCOS_III\uCOS_CONFIG\cpu_cfg.h
objects\lib_math.o: ..\uCOS_III\uCOS_CPU\cpu_core.h
objects\lib_math.o: ..\uCOS_III\uCOS_LIB\lib_def.h
