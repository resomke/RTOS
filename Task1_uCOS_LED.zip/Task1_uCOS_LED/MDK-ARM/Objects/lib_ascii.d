objects\lib_ascii.o: ..\uCOS_III\uCOS_LIB\lib_ascii.c
objects\lib_ascii.o: ..\uCOS_III\uCOS_LIB\lib_ascii.h
objects\lib_ascii.o: ..\uCOS_III\uCOS_CPU\ARM-Cortex-M3\RealView\cpu.h
objects\lib_ascii.o: ..\uCOS_III\uCOS_CPU\cpu_def.h
objects\lib_ascii.o: ..\uCOS_III\uCOS_CONFIG\cpu_cfg.h
objects\lib_ascii.o: ..\uCOS_III\uCOS_LIB\lib_def.h
